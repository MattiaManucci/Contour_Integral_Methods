function [A,b_l,u0,dom] = OPERATORs(N,T,flag)
% This fuction construct the Hestor or the Black-Scholes or the simple convection-diffusion operator and their forzant term
%% Input:
% flag: if flag=0 returns BS operator, if flag=1 returns Heston Operator; if flag=2 returns Classical Convection-Diffusion Operator;
% N: size of the operator;
% T: required final time (need for Heston);
%% Output:
% A matrix arised from operator;
% b_l known term;
% u0 intiial solution;
% dom domain mesh
if flag==0
    sigma=0.05; r=0.06; K=8e1;
    S=0; L=200; m=N;
    ds=(S-L)/(m+1); s=((L+ds):ds:(S-ds))'; dom=s;
    u0=@(s) max(0,s-K); %Initial Solution
    u0=u0(s);
    B(:,3)=(sigma^2*s.^2)/(2*(ds^2))-r*s./(2*ds); B(:,1)=(sigma^2*s.^2)./(2*(ds^2))+r*s./(2*ds);
    B(:,2)=-(sigma^2*s.^2)/(ds^2)-r;
    A=spdiags(B,[-1,0,1],m,m)';
    %Forzant term (comes from non-omogeneous Dirichlet)
    b1=zeros(m,1); b2=b1;
    b1(end)=((sigma^2*s(end)^2)/(2*(ds^2))+r*s(end)/(2*ds))*S; b2(end)=(sigma^2*s(end)^2/(2*(ds^2))+r*s(end)/(2*ds))*K;
    b_l=@(z) (z^-1)*b1-((z+r)^-1).*b2;
end
if flag==1
    %% Inizializations
    K=100;           % strike
    kappa = 1.5;    % mean-reversion rate
    eta   = 0.04;    % long-term mean
    rho   = -0.9;   % correlation
    rf    = 0.0;    % foreign rate
    sigma=0.3; r=0.025;
    %Space Disc Sizes
    m1=N(1); m2=N(2); M1 = m1+1; M2 = m2+1; ev = ones(M2,1); E(M1,:) = ev;
    ii = 2:M1; jj = 1:m2; 
    %% Bulding the OFFLINE matrix
    [Y,Dvm,Dsm,X,Dss,Iv,Ds,Id,Dvv,Dv,Is,Dsmt,Dvmt,Xt,Yt,Dsst,Dvvt,Dst,Dvt,Ivt,u0,S,V,G,~,ds,~] = Heston_Matrix(m1,m2,K,T);
    %% OFFLINE STUCTURES
    dom=cell(2,1); dom{1}=S; dom{2}=V;
    A0 = kron(Y*Dvm,X*Dsm);
    A1_1 = kron(Y,0.5*X*X*Dss);  A1_2=kron(Iv,X*Ds); A1_3=-(0.5)*Id;
    A2_1 = kron((0.5)*Y*Dvv,Is); A2_2=kron(kappa*(eta*Iv-Y)*Dv,Is); A2_3=-(0.5)*Id;
    g0_1 = Xt*Dsmt*G*(Dvmt.')*Yt; g0 = g0_1(ii,jj); g0 = g0(:);
    g1_1 = 0.5*Xt*Xt*(Dsst*G+(2/ds(m1))*E)*Yt; g1_1=g1_1(ii,jj); g1_1 = g1_1(:);
    g1_2 = Xt*(Dst*G+E); g1_2=g1_2(ii,jj); g1_2 = g1_2(:);
    g2_1 = (0.5)*G*(Dvvt.')*Yt; g2_1=g2_1(ii,jj); g2_1 = g2_1(:);
    g2_2 = kappa*G*(Dvt.')*(eta*Ivt-Yt); g2_2=g2_2(ii,jj); g2_2=g2_2(:);
    %% Assembling
    A=rho*sigma*A0+A1_1+(r-rf)*A1_2+r*A1_3+sigma^2*A2_1+A2_2+r*A2_3;
    g=rho*sigma*g0+g1_1+(r-rf)*g1_2+(sigma^2)*g2_1+g2_2;
    b_l=@(z) 1/z*g;
end
if flag==2
    sigma=1; r=1; 
    S=0; L=400; m=N;
    ds=(S-L)/(m+1); s=((L+ds):ds:(S-ds))'; dom=s;
    u0=@(s) s*0; %Initial Solution
    u0=u0(s);
    B(:,3)=ones(size(s))*((sigma)./(2*(ds^2))-r./(2*ds)); B(:,1)=ones(size(s))*((sigma)./(2*(ds^2))+r./(2*ds));
    B(:,2)=-ones(size(s))*((sigma)./(ds^2));
    A=spdiags(B,[-1,0,1],m,m)';
    %Forzant term (comes from non-omogeneous Dirichlet)
    b1=zeros(m,1); 
    b1(end)=((sigma)/(2*(ds^2))+r./(2*ds)); 
    b_l=@(z) (z^-1)*b1;
end
end

