%% Function to determine the pseudospectral critical curve and the parabolic integration profile
function [a_p,c_p,KK,y_par,map_o_p,a1_p_gamma,a2_p_gamma,c_max_p,ti,tf,N_p] = Parabolic_Map_TW(A,b_l,u0,Ar,eps1,T,nX,zl,zr,tol)
%% Input:
% -A, the matrix of the problem;
% -b_l, the Laplace transfrom of the rhs;
% -u0, initial solution;
% -Ar, coarse discretization of the operator A considered;
% -eps1, target value for the weighted Pseudospectra level curve;
% -T, time widnow where we would like to compute the solution;
% -nX, maximum number of points where we compute the pseudospctra;
% -zl, see [1];
% -zr, the coordinate of the intersection with the real axes;
% -zc, the center of the hyperbolic profile;
% -tol, target accuracy for the solution;
%% Output:
% -a_p, uniquely defines the map;
% -c_p, determines the truncation of the contour integral;
% -y_p, profile of the critical ellipse;
% -map_o_p, determined map of the contour;
% -a1_p_gamma, see (16) in [1];
% -a2_p_gamma, see (17) in [1];
% -c_max_p, maximum value of the truncation parameter;
% -ti, computed initial time;
% -tf, computed final time;
% -N_p, see (59) in [1];
%% References
% [1] N. Guglielmi, M. L�pez-F�rnandez and M. Manucci, A new pseudospectral roaming contour integral method for solving
% convection diffusion equations, arxiv, 2020.
%% Inizializations
XX=linspace(zl,zr,nX); jj=fix(sqrt(nX)); jj2=2;
r=0.1; d=sum(XX)/numel(XX);
y_par=r*sqrt(zr-XX)/(sqrt(zr-d));
I=speye(size(Ar)); pp=2;
S_1=zeros(1,nX); S_2=zeros(1,nX);
q=0; j=1; tol_N=1e-2; K=[]; t=T(1);
%% Determination of the critical curve
while j<=(nX-1)
    K=[K,j];
    [U_1,S_1(j),V_1] = svds((Ar-(XX(j)+1i*y_par(j))*I),1,'smallestnz');
    S_2(j)=S_1(j).*exp(-t*XX(j));
    if ((S_1(j)*exp(-t*XX(j))+(eps1*tol_N))<eps1)
        if j-jj2+1>0
            % Note: if k is not a number but a vector the algorithm does
            % not work
            k=K(end);
            flag=2;
            if (S_1(j)*exp(-t*XX(j))+(eps1*tol_N))>eps1
                flag=3;
                y_par=r*sqrt(zr-XX)/sqrt(zr-d);
            end
            for it=1:100
                if flag==2
                    s_2=S_2(j); u_1=U_1; v_1=V_1;
                    rr2=r;
                    s2=(rr2/((eps1)*(((eps1-s_2)/eps1)/(real(1i*u_1'*v_1)...
                        *((sqrt(zr-XX(k)))/((zr-d)^(0.5)))))));
                    if s2<0.5
                        rr2=rr2+(1/pp)*s2*(eps1)*((eps1-s_2)/eps1)/(real(1i*u_1'*v_1)...
                            *((sqrt(zr-XX(k)))/((zr-d)^(0.5))));
                    else
                        rr2=rr2+(eps1)*((eps1-s_2)/eps1)/(real(1i*u_1'*v_1)...
                            *((sqrt(zr-XX(k)))/((zr-d)^(0.5))));
                    end
                    y_par=rr2*sqrt(zr-XX)/sqrt(zr-d);
                    r=rr2;
                    [U_1,S,V_1]  = svds((Ar-(XX(k)+1i*y_par(k))*I),1,'smallestnz');
                    s_2=S.*exp(-t*XX(k));
                    S_2(j)=s_2;
                    
                    if (S*exp(-t*XX(j))+(eps1*tol_N))>eps1
                        break
                    end
                end
            end
            j=j-jj2+1;
            q=q+1;
        else
            j=j+1+q;
            q=0;
        end
    else
        j=j+jj;
    end
end
%% Second part of the Function where a and c are compted
%% Definition of the Map
rr=r; X=XX;
a1_p=@(a) -rr/(2*sqrt(zr-d))-a; 
a2_p=@(a) zr-a.^2-2*a.*a1_p(a); 

fre_p=@(a,x) a^2+2*a1_p(a)*a+a2_p(a)-x.^2; %real part of the parabola
fim_p=@(a,x) -2*x*(a+a1_p(a));           %imaginary part of the parabola
map_o_p=@(a,x) fre_p(a,x)+1i*fim_p(a,x); %Parabolic Map
%% Determination of amax
am_p=(5/3)*1e1;
c_max_p=@(a) (1/pi)*sqrt(-X(1)+zr+a.^2+(a.*rr)/(zr-d));
D_p=@(a) a.^2-2*a1_p(a).*a+a2_p(a);
%Estimate of costant M_left
indzeros=find(S_2==0); S_2(indzeros)=[]; XX(indzeros)=[];
[wps,indwps]=max(1./S_2); x=XX(indwps); xx=sqrt(zr-x); y=(rr*xx/sqrt(zr-d));
normb=norm(u0+b_l(x+1i*y)); normzd1=abs(-2*xx+1i*(rr/sqrt(zr-d)));
Mleft=(1/(2*pi))*wps*normb*normzd1;
f_p=@(a) (c_max_p(a)/(a))*(log(2*pi*c_max_p(a)*exp(D_p(a)*T(end))+pi*Mleft)-log(tol));
num_err=tol*10; opts.maxit = 5000; I=speye(size(A)); j=0; jmax=100;
while num_err>tol
    j=j+1;
    am_p=am_p*(3/5);
    N=f_p(am_p);
    if N>1e10
        N=1e10;
    end
    a1_p_gamma=a1_p(am_p);  a2_p_gamma=a2_p(am_p);
    fre_p_g=@(x) a2_p_gamma-x.^2;  %real part of the parabola
    fim_p_g=@(x) -2*x*a1_p_gamma; %imaginary part of the parabola
    map_p_g=@(x) fre_p_g(x)+1i*fim_p_g(x);
    
    U=(map_p_g(0)*I-A)\(u0+b_l(map_p_g(0)));
    res=norm((map_p_g(0)*I-A)*U-u0-b_l(map_p_g(0)));
    ss=svds(map_p_g(0)*I-A,1,'smallestnz',opts)^-1;
    num_err=(c_max_p(am_p)/N)*exp((a2_p_gamma-0.^2)*T(end))*ss*res*...
        abs((-2*0+1i*(-2)*(a1_p_gamma)));
    if j>jmax
        fprintf('Parabolic contour, accuracy required may be too high, we suggest to increase tol\n')
        break
    end
end
am_p=am_p*(5/3);
%% Determination of a
N=20; tol2=tol*1e-1; I=speye(size(A)); x=zeros((N-(floor(N/2+1))),1);
tf=T(end); ti=T(1); flag_TW=0;
while flag_TW==0
    err_n_i=0; err_n_f=0; err=10;  Mright=1; a_p_old=am_p;
    c_max_p=@(a) (1/pi)*sqrt(-X(1)+zr+a.^2+(a.*rr)/(zr-d));
    while err>1e-1
        
        j=j+1;
        if j>jmax
            fprintf('Parabolic contour, fail to converge in the search for the optimal N tol\n')
            break
        end
        
        f_p=@(a) (c_max_p(a)./(a)).*(log(2*pi*c_max_p(a).*exp(D_p(a)*tf)*Mright+pi*Mleft)-log(tol))+...
            1e3*(((c_max_p(a)/N).*res*ss.*(exp(((a2_p(a)))*tf)).*(abs(-2*(a1_p(a)))))>tol);
        
        aa=linspace(0,am_p,100);
        ff_p=f_p(aa); [~,ind]=min(ff_p);
        a_p=(aa(ind));
        a1_p_gamma=a1_p(a_p);  a2_p_gamma=a2_p(a_p);
        fre_p=@(a,x) a^2+2*a1_p_gamma*a+a2_p_gamma-x.^2; %real part of the parabola
        fim_p=@(a,x) -2*x*(a+a1_p_gamma);           %imaginary part of the parabola
        map_o_p=@(a,x) fre_p(a,x)+1i*fim_p(a,x); %Parabolic map
        
        U=(map_o_p(0,0)*I-A)\(u0+b_l(map_o_p(0,0)));
        res=norm((map_o_p(0,0)*I-A)*U-u0-b_l(map_o_p(0,0)));
        ss=svds(map_o_p(0,0)*I-A,1,'smallestnz',opts)^-1;
        
        Mright=(1/(2*pi))*norm((map_o_p(-a_p,0)*I-A)\(u0+b_l(map_o_p(-a_p,0)))*abs(a_p^2+2*a1_p_gamma.*(-a_p)+a2_p_gamma));
        err=abs(a_p-a_p_old)/(a_p);
        a_p_old=a_p;
    end
    c_max_p= c_max_p(a_p);
    % Ceck if the amplitude of the TW is accetable
    fre_p_g=@(x) a2_p_gamma-x.^2;  %real part of the parabola
    fim_p_g=@(x) -2*x*a1_p_gamma;  %imaginary part of the parabola
    map_p_g=@(x) fre_p_g(x)+1i*fim_p_g(x);
    for i=(floor(N/2+1)):(N-1)
        x(i)=-c_max_p*pi+i*((2*c_max_p*pi)/N);
        U=(map_p_g(x(i))*I-A)\(u0+b_l(map_p_g(x(i))));
        res=norm((map_p_g(x(i))*I-A)*U-u0-b_l(map_p_g(x(i))));
        ss=svds(map_p_g(x(i))*I-A,1,'smallestnz')^-1;
%         err_n_i=err_n_i+2*(c_max_e/N)*exp(((a2_e_gamma+a1_e_gamma)*cos(x(i))+zl)*T(1))*(condi)*((rho_2)^(-1))*eps*max(max(abs(map_e_g(x(i))*I-A)))*norm(U)*...
%             abs(-(a2_e_gamma+a1_e_gamma)*sin(x(i))+1i*(-a2_e_gamma+a1_e_gamma)*cos(x(i)));
%         err_n_f=err_n_f+2*(c_max_e/N)*exp(((a2_e_gamma+a1_e_gamma)*cos(x(i))+zl)*T(end))*(condi)*((rho_2)^(-1))*eps*max(max(abs(map_e_g(x(i))*I-A)))*norm(U)*...
%             abs(-(a2_e_gamma+a1_e_gamma)*sin(x(i))+1i*(-a2_e_gamma+a1_e_gamma)*cos(x(i)));
        err_n_i=err_n_i+2*(c_max_p/N)*exp((a2_p_gamma-x(i).^2)*T(1))*ss*res*...
            abs((-2*x(i)+1i*(-2)*(a1_p_gamma)));
        err_n_f=err_n_f+2*(c_max_p/N)*exp((a2_p_gamma-x(i).^2)*T(end))*ss*res*...
            abs((-2*x(i)+1i*(-2)*(a1_p_gamma)));

    end
    if (err_n_i>tol2)
        ti=(T(1)+T(end))*0.5; T(1)=ti;
        fprintf('Amplitude of the time window is possibly too high to have error of the order of tol in the parabolic contour, we proceeded increasing the initial time so that the amplitude is halved\n')
    end
    if (err_n_f>tol2)
         tf=(T(1)+T(end))*0.5; T(end)=tf;
         fprintf('Amplitude of the time window is possibly too high to have error of the order of tol in the parabolic contour, we proceeded decreasing the final time so that the amplitude is halved\n')
    end
    if  (err_n_i>tol2)&&(err_n_f>tol2)&&(err_n_i/err_n_f<10)&&(err_n_i/err_n_f>0.1)
        tf=tf+(tf-T(1)); T(end)=tf;
        ti=ti-(tf-T(1)); T(1)=ti;
        fprintf('The problem is possibly ill conditioned, we suggest to lower the tolerance\n')
        break
    end
    if (err_n_i<tol2)&&((err_n_f<tol2))
        break
    end
end
%% Determination of the truncation value c for the parabolic contour
%Inizializations
prec=1e-2; K0=80; j=0; jmax=20;
K=K0-2*prec; I=speye(size(A)); c_p=zeros(size(T)); KK=c_p;
fre_p_g=@(x) a2_p_gamma-x.^2;  %real part of the parabola
fim_p_g=@(x) -2*x*a1_p_gamma; %imaginary part of the parabola
map_p_g=@(x) fre_p_g(x)+1i*fim_p_g(x);
for i=1:numel(T)
    while abs(K-K0)>=prec
        
        c_p(i)=(1/pi)*sqrt(a2_p_gamma-(1/T(i))*log(tol/K));
        u=(map_p_g(c_p(i)*pi)*I-A)\(u0+b_l(map_p_g(c_p(i)*pi)));
        K0=K;
        K=(1/(2*pi))*norm(u*(-2*c_p(i)*pi+1i*(-2)*(a1_p_gamma)));
        j=j+1;
        if j>jmax
            fprintf('Algorithm for trunctaion did not converge, maximum truncation value automatically selected\n')
            c_p(i)=c_max_p;
            K=(1/(2*pi))*norm(u*(-2*c_p(i)*pi+1i*(-2)*(a1_p_gamma)));
            break
        end
    end
    
    if imag(c_p(i))>eps
        fprintf('Algorithm for trunctaion converged to a complex number, maximum truncation value automatically selected\n')
        c_p(i)=c_max_p;
        K=(1/(2*pi))*norm(u*(-2*c_p(i)*pi+1i*(-2)*(a1_p_gamma)));
    end
    KK(i)=K; K0=80;
end
f_p=@(a) (c_p(1)/(a))*(log(2*pi*c_p(1)*exp(D_p(a)*tf)*Mright+pi*Mleft)-log(tol));
N_p=f_p(a_p);
end