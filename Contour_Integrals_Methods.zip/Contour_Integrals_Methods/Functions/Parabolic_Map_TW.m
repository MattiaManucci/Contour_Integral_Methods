%% Function to determine the pseudospectral critical curve and the parabolic integration profile
function [a_p,c_p,KK,y_par,map_o_p,a1_p_gamma,a2_p_gamma,c_max_p,ti,tf,N_p] = Parabolic_Map_TW(A,b_l,u0,Ar,eps1,eps2,T,nX,zl,zr,tol)
%% Input:
% -A, the matrix of the problem;
% -b_l, the Laplace transfrom of the rhs;
% -u0, initial solution;
% -Ar, coarse discretization of the operator A considered;
% -eps1, target value for the weighted Pseudospectra level curve;
% -eps2, target value for the Pseudospectra level curve;
% -T, time widnow where we would like to compute the solution;
% -nX, maximum number of points where we compute the pseudospctra;
% -zl, see [1];
% -zr, the coordinate of the intersection with the real axes;
% -zc, the center of the hyperbolic profile;
% -tol, target accuracy for the solution;
%% Output:
% -a_p, uniquely defines the map;
% -c_p, determines the truncation of the contour integral;
% -y_p, profile of the critical ellipse;
% -map_o_p, determined map of the contour;
% -a1_p_gamma, see (16) in [1];
% -a2_p_gamma, see (17) in [1];
% -c_max_p, maximum value of the truncation parameter;
% -ti, computed initial time;
% -tf, computed final time;
% -N_p, see (49) in [1];
%% References
% [1] N. Guglielmi, M. L�pez-F�rnandez and M. Manucci, A new pseudospectral roaming contour integral method for solving
% convection diffusion equations, arxiv, 2020.
%% Inizializations
XX=linspace(zl,zr,nX); jj=fix(sqrt(nX)); jj2=2;
r=0.1; d=sum(XX)/numel(XX);
y_par=r*sqrt(zr-XX)/(sqrt(zr-d));
I=speye(size(Ar)); pp=2;
U_1=zeros(size(Ar,1),nX); V_1=zeros(size(Ar,1),nX); S_1=zeros(1,nX); S_2=zeros(1,nX);
flag=1; q=0; j=1; tol_N=1e-2; K=[]; t=T(1);
%% Determination of the critical curve
while j<=(nX-1)
    K=[K,j];
    [U,S,V] = svd(full(Ar-(XX(j)+1i*y_par(j))*I),'econ');
    U_1(:,j)=U(:,end); V_1(:,j)=V(:,end); S_1(j)=S(end,end); S_2(j)=S(end,end).*exp(-t*XX(j));
    if ((S(end,end)+(eps2*tol_N))<eps2)||((S(end,end)*exp(-t*XX(j))+(eps1*tol_N))<eps1)
        if j-jj2+1>0
            if S_1(j-jj2+1)<=eps2
                s_2=S_2(j); s_1=S(end,end); u_1=U(:,end); v_1=V(:,end);
                % Note: if k is not a number but a vector the algorithm does
                % not work
                k=K(end);
                
                if (S(end,end)+(eps2*tol_N))>eps2
                    
                    flag=2;
                    if (S(end,end)*exp(-t*XX(j))+(eps1*tol_N))>eps1
                        flag=3;
                        y_par=r*sqrt(zr-XX)/sqrt(zr-d);
                    end
                end
                
                for it=1:100
                    
                    if flag==1
                        rr=r; d0=d;
                        s2=(rr/((eps2)*(((eps2-s_1)/eps2)/(real(1i*u_1'*v_1)...
                            *((sqrt(zr-XX(k)))/((zr-d0)^(0.5)))))));
                        if s2<0.5
                            rr=rr+(1/pp)*s2*(eps2)*(((eps2-s_1)/eps2)/(real(1i*u_1'*v_1)...
                                *((sqrt(zr-XX(k)))/((zr-d0)^(0.5)))));
                        else
                            rr=rr+(eps2)*(((eps2-s_1)/eps2)/(real(1i*u_1'*v_1)...
                                *((sqrt(zr-XX(k)))/((zr-d0)^(0.5)))));
                        end
                        
                        y_par=rr*sqrt(zr-XX)/sqrt(zr-d);
                        [U,S,V] = svd(full(Ar-(XX(k)+1i*y_par(k))*I),'econ');
                        u_1=U(:,end); v_1=V(:,end); s_1=S(end,end); s_2=S(end,end).*exp(-t*XX(k));
                        r=rr;
                        if (S(end,end)+(eps2*tol_N))>eps2
                            if (S(end,end)*exp(-t*XX(j))+(eps1*tol_N))>eps1
                                break
                            else
                                
                                flag=2;
                            end
                        end
                    end
                    if flag==2
                        
                        rr2=r;
                        s2=(rr2/((eps1)*(((eps1-s_2)/eps1)/(real(1i*u_1'*v_1)...
                            *((sqrt(zr-XX(k)))/((zr-d)^(0.5)))))));
                        if s2<0.5
                            rr2=rr2+(1/pp)*s2*(eps1)*((eps1-s_2)/eps1)/(real(1i*u_1'*v_1)...
                                *((sqrt(zr-XX(k)))/((zr-d)^(0.5))));
                        else
                            rr2=rr2+(eps1)*((eps1-s_2)/eps1)/(real(1i*u_1'*v_1)...
                                *((sqrt(zr-XX(k)))/((zr-d)^(0.5))));
                        end
                        y_par=rr2*sqrt(zr-XX)/sqrt(zr-d);
                        r=rr2;
                        [U,S,V] = svd(full(Ar-(XX(k)+1i*y_par(k))*I),'econ');
                        u_1=U(:,end); v_1=V(:,end); s_1=S(end,end);
                        s_2=S(end,end).*exp(-t*XX(k));
                        if (S(end,end)+(eps2*tol_N))>eps2
                            if (S(end,end)*exp(-t*XX(j))+(eps1*tol_N))>eps1
                                break
                            else
                                flag=1;
                            end
                        end
                    end
                end
                j=j-jj2+1;
                q=q+1;
            else
                j=j+1+q;
                q=0;
            end
        else
            j=j+1+q;
            q=0;
        end
    else
        j=j+jj;
    end
end
%% Second part of the Function where a and c are compted
%% Definition of the Map
rr=r; X=XX;
a1_p=@(a) -rr/(2*sqrt(zr-d))-a; 
a2_p=@(a) zr-a^2-2*a*a1_p(a); 

fre_p=@(a,x) a^2+2*a1_p(a)*a+a2_p(a)-x.^2; %real part of the parabola
fim_p=@(a,x) -2*x*(a+a1_p(a));           %imaginary part of the parabola
map_o_p=@(a,x) fre_p(a,x)+1i*fim_p(a,x); %Mappa parabola
%% Determination of a 
am_p=1e1; N=20; I=speye(size(A)); x=zeros((N-(floor(N/2+1))),1);
D_p=@(a) a^2-2*a1_p(a)*a+a2_p(a); c_ott_p=@(a) (1/pi)*sqrt(-X(1)+zr+a^2+(a*rr)/(zr-d)); tf=T(end); ti=T(1); flag_TW=0;
    
while flag_TW==0
    
    err_n_i=0; err_n_f=0;
    f_p=@(a) ( c_ott_p(a)/(a))*(D_p(a)*(tf)-log(tol/(2* c_ott_p(a)*pi)));
    a_p=fminbnd(f_p,0,am_p);  c_max_p= c_ott_p(a_p); N_p=f_p(a_p);
    a1_p_gamma=a1_p(a_p);  a2_p_gamma=a2_p(a_p);
    % Ceck if the amplitude of the TW is accetable
    fre_p_g=@(x) a2_p_gamma-x.^2;  %real part of the parabola
    fim_p_g=@(x) -2*x*a1_p_gamma; %imaginary part of the parabola
    map_p_g=@(x) fre_p_g(x)+1i*fim_p_g(x);
    for i=(floor(N/2+1)):(N-1)
        x(i)=-c_max_p*pi+i*((2*c_max_p*pi)/N);
        U=(map_p_g(x(i))*I-A)\(u0+b_l(x(i)));
        res=norm((map_p_g(x(i))*I-A)*U-u0-b_l(x(i)));
        ss=svds(map_p_g(x(i))*I-A,1,'smallestnz')^-1;
%         err_n_i=err_n_i+2*(c_max_e/N)*exp(((a2_e_gamma+a1_e_gamma)*cos(x(i))+zl)*T(1))*(condi)*((rho_2)^(-1))*eps*max(max(abs(map_e_g(x(i))*I-A)))*norm(U)*...
%             abs(-(a2_e_gamma+a1_e_gamma)*sin(x(i))+1i*(-a2_e_gamma+a1_e_gamma)*cos(x(i)));
%         err_n_f=err_n_f+2*(c_max_e/N)*exp(((a2_e_gamma+a1_e_gamma)*cos(x(i))+zl)*T(end))*(condi)*((rho_2)^(-1))*eps*max(max(abs(map_e_g(x(i))*I-A)))*norm(U)*...
%             abs(-(a2_e_gamma+a1_e_gamma)*sin(x(i))+1i*(-a2_e_gamma+a1_e_gamma)*cos(x(i)));
        err_n_i=err_n_i+2*(c_max_p/N)*exp((a2_p_gamma-x(i).^2)*T(1))*ss*res*...
            abs((-2*x(i)+1i*(-2)*(a1_p_gamma)));
        err_n_f=err_n_f+2*(c_max_p/N)*exp((a2_p_gamma-x(i).^2)*T(end))*ss*res*...
            abs((-2*x(i)+1i*(-2)*(a1_p_gamma)));

    end
    if (err_n_i>tol)
        ti=(T(1)+T(end))*0.5; T(1)=ti;
        fprintf('Amplitude of the time window is possibly too high to have error of the order of tol in the elliptic contour, we proceeded increasing the initial time so that the amplitude is halved\n')
    end
    if (err_n_f>tol)
         tf=(T(1)+T(end))*0.5; T(end)=tf;
         fprintf('Amplitude of the time window is possibly too high to have error of the order of tol in the elliptic contour, we proceeded decreasing the final time so that the amplitude is halved\n')
    end
    if   (err_n_i>tol)&&(err_n_f>tol)&&(err_n_i/err_n_f<10)&&(err_n_i/err_n_f>0.1)
        tf=tf+(tf-T(1)); T(end)=tf;
        ti=ti-(tf-T(1)); T(1)=ti;
        fprintf('The problem is possibly ill conditioned, we suggest to lower the tolerance')
        break
    end
    if (err_n_i<tol)&&((err_n_f<tol))
        break
    end
end
%% Determination of the truncation value c for the ellisse
%Inizializations
prec=1e-2; K0=80; j=0; jmax=20;
K=K0-2*prec; I=speye(size(A)); c_p=zeros(size(T)); KK=c_p;
fre_p_g=@(x) a2_p_gamma-x.^2;  %real part of the parabola
fim_p_g=@(x) -2*x*a1_p_gamma; %imaginary part of the parabola
map_p_g=@(x) fre_p_g(x)+1i*fim_p_g(x);
for i=1:numel(T)
    while abs(K-K0)>=prec
        
        c_p(i)=(1/pi)*sqrt(a2_p_gamma-(1/T(i))*log(tol/K));
        u=(map_p_g(c_p(i)*pi)*I-A)\(u0+b_l(map_p_g(c_p(i)*pi)));
        K0=K;
        K=(1/(2*pi))*norm(u*(-2*c_p(i)*pi+1i*(-2)*(a1_p_gamma)));
        j=j+1;
        if j>jmax
            fprintf('Algorithm for trunctaion did not converge, maximum truncation value automatically selected\n')
            c_p(i)=c_max_p;
            K=(1/(2*pi))*norm(u*(-2*c_p(i)*pi+1i*(-2)*(a1_p_gamma)));
            break
        end
    end
    
    if real(c_p(i))<=eps
        fprintf('Algorithm for trunctaion converged to imaginary number, maximum truncation value automatically selected\n')
        c_p(i)=c_max_p;
        K=(1/(2*pi))*norm(u*(-2*c_p(i)*pi+1i*(-2)*(a1_p_gamma)));
    end
    KK(i)=K; K0=80;
end
end