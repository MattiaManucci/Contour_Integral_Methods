%% Function to determine the pseudospectral critical curve and the elliptic integration profiles
function [a_e,c_e,KK,y_el,map_o_e,a1_e_gamma,a2_e_gamma,c_max_e,ti,tf,N_e] = Elliptic_Map_TW(A,b_l,u0,Ar,eps1,eps2,T,nX,zl,zr,tol)
%% Input:
% -A, the matrix of the problem;
% -b_l, the Laplace transfrom of the rhs;
% -u0, initial solution;
% -Ar, coarse discretization of the operator A considered;
% -eps1, target value for the weighted Pseudospectra level curve;
% -eps2, target value for the Pseudospectra level curve;
% -T, time window where I would like to compute the solution;
% -nX, maximum number of points where we compute the pseudospctra;
% -zl, the center of the ellipse;
% -zr, the coordinate of the intersection with the real axes;
% -tol, target accuracy for the solution;
%% Output:
% -a_e, uniquely defines the map;
% -c_e, determines the truncation of the contour integral at t0 and t1;
% -KK, need to determine the truncation value c_e;
% -y_el, profile of the critical ellips;
% -map_o_e, determined map of the contour;
% -a1_e_gamma, see (13) in [1];
% -a2_e_gamma, see (14) in [1];
% -c_max_e, maximum value of the truncation parameter;
% -ti, computed initial time;
% -tf, computed final time;
% -N_e, see (49) in [1];
%% References
% [1] N. Guglielmi, M. L�pez-F�rnandez and M. Manucci, A new pseudospectral roaming contour integral method for solving
% convection diffusion equations, arxiv, 2020.
%% Inizializations
XX=linspace(zl,zr,nX); jj=fix(sqrt(nX)); jj2=2;
r=0.1; d=sum(XX)/numel(XX); teta=acos((d-zl)/(zr-zl));
y_el=(r/sin(teta))*sin(acos((XX-zl)/(zr-zl))); %Critical Ellipse
I=speye(size(Ar)); pp=2;
U_1=zeros(size(Ar,1),nX); V_1=zeros(size(Ar,1),nX); S_1=zeros(1,nX); S_2=zeros(1,nX);
flag=1; q=0; j=1; tol_N=1e-2; K=[]; t=T(1);
%% First part of the function: determination of the critical curve
while j<=(nX-1)
    K=[K,j];
    [U,S,V] = svd(full(Ar-(XX(j)+1i*y_el(j))*I),'econ');
    U_1(:,j)=U(:,end); V_1(:,j)=V(:,end); S_1(j)=S(end,end); S_2(j)=S(end,end).*exp(-t*XX(j));
    if ((S(end,end)+(eps2*tol_N))<eps2)||((S(end,end)*exp(-t*XX(j))+(eps1*tol_N))<eps1)
        if j-jj2+1>0
            if (S_1(j-jj2+1)<eps2)
                s_2=S_2(j); s_1=S(end,end); u_1=U(:,end); v_1=V(:,end);
                % Note: if k is not a number but a vector the algorithm does
                % not work
                k=K(end);
              
                if (S(end,end)+(eps2*tol_N))>eps2
                    
                    flag=2;
                    if (S(end,end)*exp(-t*XX(j))+(eps1*tol_N))>eps1
                        flag=3;
                        y_el=r*sin(acos((XX-zl)/(zr-zl)))/sin(acos((d-zl)/(zr-zl)));
                    end
                end
                
                for it=1:100
                    
                    if flag==1
                        r0=r;
                        teta=acos((d-zl)/(zr-zl)); phi=acos((XX(k)-zl)/(zr-zl));
                        s2=(r/(pp*(eps2)*((eps2-s_1)/eps2)/(real(1i*u_1'*v_1)...
                            *(sin(phi)/sin(teta)))));
                        if s2<0.5
                            r=r0+(1/pp)*s2*(eps2)*(((eps2-s_1)/eps2)/(real(1i*u_1'*v_1)...
                                *(sin(phi)/sin(teta))));
                        else
                            r=r0+(eps2)*((eps2-s_1)/eps2)/(real(1i*u_1'*v_1)...
                                *(sin(phi)/sin(teta)));
                        end
                        
                        
                        y_el=r*sin(acos((XX-zl)/(zr-zl)))/sin(acos((d-zl)/(zr-zl)));
                        
                        [U,S,V] = svd(full(Ar-(XX(k)+1i*y_el(k))*I),'econ');
                        u_1=U(:,end); v_1=V(:,end); s_1=S(end,end);
                        s_2=S(end,end).*exp(-t*XX(k));
                        
                        
                        if (S(end,end)+(eps2*tol_N))>eps2
                            if (S(end,end)*exp(-t*XX(j))+(eps1*tol_N))>eps1
                                break
                            else
                                
                                flag=2;
                            end
                        end
                    end
                    
                    if flag==2
                        
                       r02=r; teta=acos((d-zl)/(zr-zl)); phi=acos((XX(k)-zl)/(zr-zl));
                       
                       s2=(r02/((eps1)*(((eps1-s_2)/eps1)/(real(1i*u_1'*v_1)...
                           *(sin(phi)/sin(teta))))));
                       if s2<0.5
                           rr2=r02+(1/pp)*s2*(eps1)*(max((eps1-s_2)/eps1)/(real(1i*u_1'*v_1)...
                               *(sin(phi)/sin(teta))));
                       else
                           rr2=r02+(eps1)*(max((eps1-s_2)/eps1)/(real(1i*u_1'*v_1)...
                               *(sin(phi)/sin(teta))));
                       end
                       
                       y_el=rr2*sin(acos((XX-zl)/(zr-zl)))/sin(acos((d-zl)/(zr-zl)));
                       
                       [U,S,V] = svd(full(Ar-(XX(k)+1i*y_el(k))*I),'econ');
                       u_1=U(:,end); v_1=V(:,end); s_1=S(end,end);
                       s_2=S(end,end).*exp(-t*XX(k));
                       r=rr2;
                       
                       if (S(end,end)+(eps2*tol_N))>eps2
                            if (S(end,end)*exp(-t*XX(j))+(eps1*tol_N))>eps1
                                break
                            else
                                flag=1;
                            end
                       end
                    end
                end
                j=j-jj2+1;
                q=q+1;
            else
                j=j+1+q;
                q=0;
            end
        else
            j=j+1+q;
            q=0;
        end
    else
        j=j+jj;
    end
end
%% Second part of the Function where a and c are compted
%% Definition of the Map
rr_e=r; d_e=d;
a1_e=@(a) 0.5*exp(-a)*(zr-zl-rr_e/(sin(acos((d_e-zl)/(zr-zl)))));
a2_e=@(a) 0.5*exp(a)*(zr-zl+rr_e/(sin(acos((d_e-zl)/(zr-zl)))));

fre_e=@(a,x) (a1_e(a)*exp(a)+a2_e(a)*exp(-a))*cos(x)+zl; %real part of the ellisse
fim_e=@(a,x) (a2_e(a)*exp(-a)-a1_e(a)*exp(a))*sin(x);    %imaginary part of the ellisse
map_o_e=@(a,x) fre_e(a,x)+1i*fim_e(a,x); %Ellipse Map
%% Determination of a 
am_e=1e0; N=10; I=speye(size(A)); x=zeros((N-(floor(N/2+1))),1);
D_e=@(a) a1_e(a).*exp(-a)+a2_e(a).*exp(a)+zl; c_ott_e=@(a) 0.5; tf=T(end); ti=T(1); flag_TW=0;
    
while flag_TW==0
    
    err_n_i=0; err_n_f=0;
    f_e=@(a) ( c_ott_e(a)/(a))*(D_e(a)*(tf)-log(tol/(2* c_ott_e(a)*pi)));
    a_e=fminbnd(f_e,0,am_e);  c_max_e= c_ott_e(a_e); N_e=f_e(a_e);
    a1_e_gamma=a1_e(a_e);  a2_e_gamma=a2_e(a_e);
    % Ceck if the amplitude of the TW is accetable
    fre_e_g=@(x) (a1_e_gamma*exp(0)+a2_e_gamma*exp(0))*cos(x)+zl; %real part of the ellisse
    fim_e_g=@(x) (a2_e_gamma*exp(0)-a1_e_gamma*exp(0))*sin(x);    %imaginary part of the ellisse
    map_e_g=@(x) fre_e_g(x)+1i*fim_e_g(x);
    for i=(floor(N/2+1)):(N-1)
        x(i)=-c_max_e*pi+i*((2*c_max_e*pi)/N);
        U=(map_e_g(x(i))*I-A)\(u0+b_l(x(i)));
        res=norm((map_e_g(x(i))*I-A)*U-u0-b_l(x(i)));
        ss=svds(map_e_g(x(i))*I-A,1,'smallestnz')^-1;
%         err_n_i=err_n_i+2*(c_max_e/N)*exp(((a2_e_gamma+a1_e_gamma)*cos(x(i))+zl)*T(1))*(condi)*((rho_2)^(-1))*eps*max(max(abs(map_e_g(x(i))*I-A)))*norm(U)*...
%             abs(-(a2_e_gamma+a1_e_gamma)*sin(x(i))+1i*(-a2_e_gamma+a1_e_gamma)*cos(x(i)));
%         err_n_f=err_n_f+2*(c_max_e/N)*exp(((a2_e_gamma+a1_e_gamma)*cos(x(i))+zl)*T(end))*(condi)*((rho_2)^(-1))*eps*max(max(abs(map_e_g(x(i))*I-A)))*norm(U)*...
%             abs(-(a2_e_gamma+a1_e_gamma)*sin(x(i))+1i*(-a2_e_gamma+a1_e_gamma)*cos(x(i)));
        err_n_i=err_n_i+2*(c_max_e/N)*exp(((a2_e_gamma+a1_e_gamma)*cos(x(i))+zl)*T(1))*ss*res*...
            abs(-(a2_e_gamma+a1_e_gamma)*sin(x(i))+1i*(-a2_e_gamma+a1_e_gamma)*cos(x(i)));
        err_n_f=err_n_f+2*(c_max_e/N)*exp(((a2_e_gamma+a1_e_gamma)*cos(x(i))+zl)*T(end))*ss*res*...
            abs(-(a2_e_gamma+a1_e_gamma)*sin(x(i))+1i*(-a2_e_gamma+a1_e_gamma)*cos(x(i)));

    end
    if (err_n_i>tol)
        ti=(T(1)+T(end))*0.5; T(1)=ti;
        fprintf('Amplitude of the time window is possibly too high to have error of the order of tol in the elliptic contour, we proceeded increasing the initial time so that the amplitude is halved\n')
    end
    if (err_n_f>tol)
         tf=(T(1)+T(end))*0.5; T(end)=tf;
         fprintf('Amplitude of the time window is possibly too high to have error of the order of tol in the elliptic contour, we proceeded decreasing the final time so that the amplitude is halved\n')
    end
    if   (err_n_i>tol)&&(err_n_f>tol)&&(err_n_i/err_n_f<10)&&(err_n_i/err_n_f>0.1)
        tf=tf+(tf-T(1)); T(end)=tf;
        ti=ti-(tf-T(1)); T(1)=ti;
        fprintf('The problem is possibly ill conditioned, we suggest to lower the tolerance')
        break
    end
    if (err_n_i<tol)&&((err_n_f<tol))
        break
    end
end
%% Determination of the truncation value c for the ellisse
%Inizializations
prec=1e-2; K0=80; j=0; jmax=20;
K=K0-2*prec; c_e=zeros(size(T)); KK=c_e;
for i=1:numel(T)
    while abs(K-K0)>=prec
        
        c_e(i)=(1/pi)*acos((1/((a1_e_gamma*exp(0)+a2_e_gamma*exp(0))*T(i)))*log(tol/K)...
            -zl/(a1_e_gamma*exp(0)+a2_e_gamma*exp(0)));
        u=(map_e_g(c_e(i)*pi)*I-A)\(u0+b_l(map_e_g(c_e(i)*pi)));
        K0=K;
        K=(1/(2*pi))*norm(u*(-(a1_e_gamma*exp(0)+a2_e_gamma*exp(0))*sin(c_e(i)*pi)+...
            1i*(a2_e_gamma*exp(0)-a1_e_gamma*exp(0))*cos(c_e(i)*pi)));
        j=j+1;
        if j>jmax
            fprintf('Algorithm for trunctaion did not converge, maximum truncation value automatically selected\n')
            c_e(i)=c_max_e;
            K=(1/(2*pi))*norm(u*(-(a1_e_gamma*exp(0)+a2_e_gamma*exp(0))*sin(c_e(i)*pi)+...
            1i*(a2_e_gamma*exp(0)-a1_e_gamma*exp(0))*cos(c_e(i)*pi)));
            break
        end
        if j>1e1
            c_e(i)=c_max_e;
            break
        end
        
    end
    if real(c_e(i))<=eps
        fprintf('Algorithm for trunctaion converged to imaginary number, maximum truncation value automatically selected\n')
        c_e(i)=c_max_e;
    end
    KK(i)=K; K0=80;
end
end