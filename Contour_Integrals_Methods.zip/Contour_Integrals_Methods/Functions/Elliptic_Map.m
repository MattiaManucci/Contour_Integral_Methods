%% Function to determine the pseudospectral critical curve and the integration contour with an elliptic profile
function [a_e,c_e,y_el,map_o_e,a1_e_gamma,a2_e_gamma,c_max_e,N_e] = Elliptic_Map(A,b_l,u0,Ar,eps1,t,nX,zl,zr,tol)
%% Input:
% -A, the matrix of the problem;
% -b_l, the Laplace transfrom of the rhs;
% -u0, initial solution;
% -Ar, coarse discretization of the operator A considered;
% -eps1, target value for the weighted Pseudospectra level curve;
% -t, time where we would like to compute the solution;
% -nX, maximum number of points where we compute the pseudospctra;
% -zl, the center of the ellipse;
% -zr, the coordinate of the intersection with the real axes;
% -tol, target accuracy for the solution;
%% Output:
% -a_e, uniquely defines the map;
% -c_e, determines the truncation of the contour integral;
% -y_el, profile of the critical ellipse;
% -map_o_e, determined map of the contour;
% -a1_e_gamma, see (13) in [1];
% -a2_e_gamma, see (14) in [1];
% -c_max_e, maximum value of the truncation parameter;
% -N_e, see (59) in [1];
%% References
% [1] N. Guglielmi, M. López-Férnandez and M. Manucci, A new pseudospectral roaming contour integral method for solving
% convection diffusion equations,arxiv, 2020.
%% Inizializations
XX=linspace(zl,zr,nX); jj=fix(sqrt(nX)); jj2=2;
r=0.1; d=sum(XX)/numel(XX); teta=acos((d-zl)/(zr-zl));
y_el=(r/sin(teta))*sin(acos((XX-zl)/(zr-zl))); %Critical Ellipse
I=speye(size(Ar)); pp=2;
S_1=zeros(1,nX); S_2=zeros(1,nX);
q=0; j=1; tol_N=1e-2; K=[];
%% First part of the function: determination of the critical curve
while j<=(nX-1)
    K=[K,j];
    [U_1,S_1(j),V_1] = svds((Ar-(XX(j)+1i*y_el(j))*I),1,'smallestnz');
    S_2(j)=S_1(j).*exp(-t*XX(j));
    if ((S_1(j)*exp(-t*XX(j))+(eps1*tol_N))<eps1)
        if j-jj2+1>0
            k=K(end);
            
            flag=2;
            if (S_1(j)*exp(-t*XX(j))+(eps1*tol_N))>eps1
                flag=3;
                y_el=r*sin(acos((XX-zl)/(zr-zl)))/sin(acos((d-zl)/(zr-zl)));
            end
            
            for it=1:100
                
                if flag==2
                    s_2=S_2(j); u_1=U_1; v_1=V_1;
                    r02=r; teta=acos((d-zl)/(zr-zl)); phi=acos((XX(k)-zl)/(zr-zl));
                    
                    s2=(r02/((eps1)*(((eps1-s_2)/eps1)/(real(1i*u_1'*v_1)...
                        *(sin(phi)/sin(teta))))));
                    if s2<0.5
                        rr2=r02+(1/pp)*s2*(eps1)*(max((eps1-s_2)/eps1)/(real(1i*u_1'*v_1)...
                            *(sin(phi)/sin(teta))));
                    else
                        rr2=r02+(eps1)*(max((eps1-s_2)/eps1)/(real(1i*u_1'*v_1)...
                            *(sin(phi)/sin(teta))));
                    end
                    
                    y_el=rr2*sin(acos((XX-zl)/(zr-zl)))/sin(acos((d-zl)/(zr-zl)));
                    
                    [U_1,S,V_1] = svds((Ar-(XX(k)+1i*y_el(k))*I),1,'smallestnz');
                    s_2=S.*exp(-t*XX(k));
                    S_2(j)=s_2;
                    r=rr2;
                    if (S*exp(-t*XX(j))+(eps1*tol_N))>eps1
                        break
                    end
                end
            end
            j=j-jj2+1;
            q=q+1;
            
        else
            j=j+1+q;
            q=0;
        end
    else
        j=j+jj;
    end
end
%% Second part of the function where a and c are computed
%% Definition of the Map
rr_e=r; d_e=d;
a1_e=@(a) 0.5*exp(-a)*(zr-zl-rr_e/(sin(acos((d_e-zl)/(zr-zl)))));
a2_e=@(a) 0.5*exp(a)*(zr-zl+rr_e/(sin(acos((d_e-zl)/(zr-zl)))));

fre_e=@(a,x) (a1_e(a)*exp(a)+a2_e(a)*exp(-a))*cos(x)+zl; %real part of the ellisse
fim_e=@(a,x) (a2_e(a)*exp(-a)-a1_e(a)*exp(a))*sin(x);    %imaginary part of the ellisse
map_o_e=@(a,x) fre_e(a,x)+1i*fim_e(a,x); %Ellipse Map
%% Determination of amax
am_e=(5/3)*1e0;
c_max_e=@(a) 0.5;
D_e=@(a) a1_e(a).*exp(-a)+a2_e(a).*exp(a)+zl; 
%Estimate of costant M_left
indzeros=find(S_2==0); S_2(indzeros)=[]; XX(indzeros)=[];
[wps,indwps]=max(1./S_2); x=XX(indwps); teta=acos((d_e-zl)/(zr-zl)); y=(rr_e/sin(teta))*sin(acos((x-zl)/(zr-zl)));
normb=norm(u0+b_l(x+1i*y)); xx=acos((x-zl)/(zr-zl)); normzd1=abs((zr-zl)*sin(xx)-1i*(r/sin(teta))*cos(xx));
Mleft=(1/(2*pi))*wps*normb*normzd1;
f_e=@(a) (c_max_e(a)./(a)).*(log(2*pi*c_max_e(a).*exp(D_e(a)*t)+pi*Mleft)-log(tol));
num_err=tol*10; opts.maxit = 5000; I=speye(size(A)); j=0; jmax=100;
while num_err>tol
    
    j=j+1;
    am_e=am_e*(3/5);
    N=f_e(am_e);

    a1_e_gamma=a1_e(am_e);  a2_e_gamma=a2_e(am_e);
    fre_e_g=@(x) (a1_e_gamma*exp(0)+a2_e_gamma*exp(0))*cos(x)+zl; %real part of the ellisse
    fim_e_g=@(x) (a2_e_gamma*exp(0)-a1_e_gamma*exp(0))*sin(x);    %imaginary part of the ellisse
    map_e_g=@(x) fre_e_g(x)+1i*fim_e_g(x);
    
    U=(map_e_g(0)*I-A)\(u0+b_l(map_e_g(0)));
    res=norm((map_e_g(0)*I-A)*U-u0-b_l(map_e_g(0)));
    ss=svds(map_e_g(0)*I-A,1,'smallestnz',opts)^-1;
    num_err=(c_max_e(am_e)/N)*exp(((a2_e_gamma+a1_e_gamma)*cos(0)+zl)*t)*ss*res*...
            abs(-(a2_e_gamma+a1_e_gamma)*sin(0)+1i*(-a2_e_gamma+a1_e_gamma)*cos(0));
   if j>jmax
       fprintf('Elliptic contour, accuracy required may be too high, we suggest to increase tol\n')
       break
   end
end
am_e=am_e*(5/3);
%% Determination of a
Mright=1; a_e_old=am_e; err=10; j=0;
while err>1e-1
    j=j+1;
    if j>jmax
        fprintf('Elliptic contour, fail to converge in the search for the optimal N\n')
        break
    end
    f_e=@(a) (c_max_e(a)./(a)).*(log(2*pi*c_max_e(a).*exp(D_e(a)*t)*Mright+pi*Mleft)-log(tol))+...
        1e3*(((c_max_e(a)/N).*res*ss*(exp(((a2_e(a)+a1_e(a))*cos(0)+zl)*t))...
        .*abs((-(a2_e(a)+a1_e(a)))*sin(0)+1i*((-a2_e(a)+a1_e(a)))*cos(0)))>tol);
    
    aa=linspace(0,am_e,100);
    ff_e=f_e(aa); [~,ind]=min(ff_e);
    a_e=(aa(ind));
    a1_e_gamma=a1_e(a_e);  a2_e_gamma=a2_e(a_e);
    fre_e=@(a,x) (a1_e_gamma*exp(a)+a2_e_gamma*exp(-a))*cos(x)+zl; %real part of the ellipse
    fim_e=@(a,x) (a2_e_gamma*exp(-a)-a1_e_gamma*exp(a))*sin(x);    %imaginary part of the ellipse
    map_o_e=@(a,x) fre_e(a,x)+1i*fim_e(a,x); %Elliptic Map
    U=(map_o_e(0,0)*I-A)\(u0+b_l(map_o_e(0,0)));
    res=norm((map_o_e(0,0)*I-A)*U-u0-b_l(map_o_e(0,0)));
    ss=svds(map_o_e(0,0)*I-A,1,'smallestnz',opts)^-1;
    
    Mright=(1/(2*pi))*norm((map_o_e(-a_e,0)*I-A)\(u0+b_l(map_o_e(-a_e,0)))...
           *abs(-(a2_e_gamma*exp(a_e)+a1_e_gamma*exp(-a_e))*sin(0)+1i*(-a2_e_gamma*exp(a_e)+a1_e_gamma*exp(-a_e))*cos(0)));
    err=abs(a_e-a_e_old)/(a_e);
    a_e_old=a_e;
end
c_max_e=c_max_e(a_e); 
%% Determination of the truncation value c for the ellipse
%Inizializations
prec=1e-2; K0=80; j=0; maxit=500;
K=2*K0; I=speye(size(A));
fre_e_g=@(x) (a1_e_gamma*exp(0)+a2_e_gamma*exp(0))*cos(x)+zl; %real part of the ellipse
fim_e_g=@(x) (a2_e_gamma*exp(0)-a1_e_gamma*exp(0))*sin(x);    %imaginary part of the ellipse
map_e_g=@(x) fre_e_g(x)+1i*fim_e_g(x); 
while abs(K-K0)/(K)>=prec
    
    c_e=(1/pi)*acos((1/((a1_e_gamma*exp(0)+a2_e_gamma*exp(0))*t))*log(tol/K)...
       -zl/(a1_e_gamma*exp(0)+a2_e_gamma*exp(0)));
    u=(map_e_g(c_e*pi)*I-A)\(u0+b_l(map_e_g(c_e*pi)));
    K0=K;
    K=(1/(2*pi))*norm(u*(-(a1_e_gamma*exp(0)+a2_e_gamma*exp(0))*sin(c_e*pi)+...
                    1i*(a2_e_gamma*exp(0)-a1_e_gamma*exp(0))*cos(c_e*pi)));
    j=j+1;
    if j>maxit
      fprintf('Algorithm for trunctaion did not converge, maximum truncation value automatically selected\n')
      c_e=c_max_e;
      break;
    end
end
if (imag(c_e)>=eps)
    fprintf('Algorithm for trunctaion converged to a complex number, maximum truncation value automatically selected\n')
    c_e=c_ott_e;
end
f_e=@(a) (c_e/(a))*(log(2*pi*c_e*exp(D_e(a)*t)*Mright+pi*Mleft)-log(tol)); N_e=f_e(a_e);
end