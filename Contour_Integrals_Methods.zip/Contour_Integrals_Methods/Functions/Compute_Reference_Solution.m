%% Function to compute the reference solution for the 3 test problems presented.
% The method used to compute the reference solution is the one described in
% [1] 
%% References
% [1] A. H. Al-Mohy and N. J. Higham, "Computing the action of the matrix exponential, with an application to exponential integrators" SIAM J. Sci. Comput., 33(2):488--511, 2011.
function [u_ex] = Compute_Reference_Solution(N,flag,A,u0,b_l,t)
% BS Test Problem
if flag==0
    sigma=0.05; r=0.06; K=8e1;
    L=0; S=200; m=N;
    ds=(S-L)/(m+1); s=((L+ds):ds:(S-ds))'; 
    %Forzant term (comes from non-omogeneous Dirichlet)
    b1=zeros(m,1); b2=b1;
    b1(end)=((sigma^2*s(end)^2)/(2*(ds^2))+r*s(end)/(2*ds))*S; b2(end)=(sigma^2*s(end)^2/(2*(ds^2))+r*s(end)/(2*ds))*K;
    %Computing the reference solution
    uu1=(A\b1); I=speye(size(A)); uu2=((r*I+A)\b2); cc=u0+uu1-uu2;
    u_ex=expmv(t,A,cc)-uu1+exp(-r*t)*uu2;
end
% Heston test Problem
if flag==1
    g=b_l(1); 
    vv=u0+A\g;
    sol=@(T) expmv(T,A,vv)-A\g;
    u_ex=sol(t);
end
% Convection-Diffusion test Problem
if flag==2
    sigma=1; r=1; 
    S=0; L=400; m=N;
    ds=(S-L)/(m+1); 
    %Forzant term (comes from non-omogeneous Dirichlet)
    b1=zeros(m,1); 
    b1(end)=((sigma)/(2*(ds^2))+r/(2*ds)); 
    %Computing the reference solution
    uu1=(A\b1); cc=u0+uu1;
    u_ex=expmv(t,A,cc)-uu1; 
end

end

