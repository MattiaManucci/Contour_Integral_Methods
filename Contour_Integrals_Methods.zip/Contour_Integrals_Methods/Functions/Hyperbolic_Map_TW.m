%% Function to determine the pseudospectral critical curve and the hyperbolic integration profile
function [a_h,c_h,KK,y_h,map_o_h,a1_h_gamma,a2_h_gamma,c_max_h,ti,tf,N_h] = Hyperbolic_Map_TW(A,b_l,u0,Ar,eps1,T,nX,zl,zr,zc,tol)
%% Input:
% -A, the matrix of the problem;
% -b_l, the Laplace transfrom of the rhs;
% -u0, initial solution;
% -Ar, coarse discretization version than the operator A considered;
% -eps1, target value for the weighted Pseudospectra level curve;
% -T, time window where we would like to compute the solution;
% -nX, maximum number of points where we compute the pseudospctra;
% -zl, see [1];
% -zr, the coordinate of the intersection with the real axes;
% -zc, the center of the hyperbolic profile;
% -tol, target accuracy for the solution;
%% Output:
% -a_h, uniquely defines the map;
% -c_h, determines the truncation of the contour integral;
% -KK, need to determine the truncation value c_e;
% -y_h, profile of the critical ellipse;
% -map_o_h, determined map of the contour;
% -a1_h_gamma, see (22) in [1];
% -a2_h_gamma, see (21) in [1];
% -c_max_h, maximum value of the truncation parameter;
% -ti, computed initial time;
% -tf, computed final time;
% -N_h, see (59) in [1];
%% References:
% [1] N. Guglielmi, M. L�pez-F�rnandez and M. Manucci, A new pseudospectral roaming contour integral method for solving
% convection diffusion equations, arxiv, 2020.
%% Inizializations
XX=linspace(zl,zr,nX); jj=fix(sqrt(nX)); jj2=2;
r=0.1; d=sum(XX)/numel(XX);
y_h=(zc-zr)*sinh(acosh((zc-XX)/(zc-zr)))/((tan(atan((1/r)*sqrt((d-zc)^2-(zr-zc)^2))))); %Initial Critical Hyperbole
I=speye(size(Ar)); pp=2;
S_1=zeros(1,nX); S_2=zeros(1,nX);
q=0; j=1; tol_N=1e-2; K=[]; t=T(1);
%% Determination of the critical curve
while j<=(nX-1)
    K=[K,j];
    [U_1,S_1(j),V_1] = svds((Ar-(XX(j)+1i*y_h(j))*I),1,'smallestnz');
    S_2(j)=S_1(j).*exp(-t*XX(j));
    if ((S_1(j)*exp(-t*XX(j))+(eps1*tol_N))<eps1)
        if j-jj2+1>0
            % Note: if k is not a number but a vector the algorithm does
            % not work
            k=K(end);
            flag=2;
            if (S_1(j)*exp(-t*XX(j))+(eps1*tol_N))>eps1
                flag=3;
                y_h=(zc-zr)*abs((r*sinh(acosh((XX-zc)/(zr-zc))))/(sqrt((d-zc)^2-(zc-zr)^2)));
            end
            for it=1:100
                if flag==2
                    s_2=S_2(j); u_1=U_1; v_1=V_1;
                    rr2=r;
                    phi=acosh((XX(k)-zc)/(zr-zc));
                    s2=(rr2(:)/((eps1)*((eps1-s_2)/eps1)/(real(1i*u_1'*v_1)...
                        *(sin(phi)/(((d-zc)^2-(zc-zr)^2)^(1.5))))));
                    if s2<0.5
                        rr2=rr2+(1/pp)*s2*(eps1)*(max(0,(eps1-s_2)/eps1)/(real(1i*u_1'*v_1)...
                            *(sin(phi)/(((d-zc)^2-(zc-zr)^2)^(1.5)))));
                    else
                        rr2=rr2+s2*(eps1)*(((eps1-s_2)/eps1)/(real(1i*u_1'*v_1)...
                            *(sin(phi)/(((d-zc)^2-(zc-zr)^2)^(1.5)))));
                    end
                    
                    y_h=(zc-zr)*abs((rr2*sinh(acosh((XX-zc)/(zr-zc))))/(sqrt((d-zc)^2-(zc-zr)^2)));
                    [U_1,S,V_1] = svds((Ar-(XX(k)+1i*y_h(k))*I),1,'smallestnz');
                    s_2=S.*exp(-t*XX(k)); S_2(j)=s_2;
                    r=rr2;
                    
                    if (S*exp(-t*XX(j))+(eps1*tol_N))>eps1
                        break
                    end
                    
                end
            end
            j=j-jj2+1;
            q=q+1;
            
        else
            j=j+1+q;
            q=0;
        end
    else
        j=j+jj;
    end
end
%% Second part of the function where we determine a and c
%% Definition of the Map
rr=r; X=XX;
a1_h=@(a) atan((1/rr).*sqrt((d-zc)^2-(zc-zr)^2))-a;
a2_h=@(a) (zc-zr)./sin(a1_h(a)+a);

fre_h=@(a,x) zc-a2_h(a)*sin(a1_h(a)-a)*(exp(x)+exp(-x))*0.5; %real part of the hyperbola
fim_h=@(a,x) a2_h(a)*cos(a1_h(a)-a)*(-exp(x)+exp(-x))*0.5;   %imaginary part of the hyperbola
map_o_h=@(a,x) fre_h(a,x)+1i*fim_h(a,x); %Hyperbolic Map
%% Determination of amax
am_h=(5/3)*3e-1;
c_max_h=@(a) (1/pi)*log((-X(1)+zc+sqrt((X(1)-zc)^2-(sin(a1_h(a))*(zc-zr)/(sin(a1_h(a)+a)))^2))/(sin(a1_h(a))*(zc-zr)/(sin(a1_h(a)+a))));
D_h=@(a) zc-a2_h(a).*sin(a1_h(a)-a);
%Estimate of costant M_+
indzeros=find(S_2==0); S_2(indzeros)=[]; XX(indzeros)=[];
[wps,indwps]=max(1./S_2); x=XX(indwps); xx=sqrt(zr-x); y=(rr*xx/sqrt(zr-d));
normb=norm(u0+b_l(x+1i*y)); normzd1=abs(-2*xx+1i*(rr/sqrt(zr-d)));
Mleft=(1/(2*pi))*wps*normb*normzd1;
f_h=@(a) (c_max_h(a)/(a))*(log(2*pi*c_max_h(a)*exp(D_h(a)*T(end))+pi*Mleft)-log(tol));
num_err=tol*10; opts.maxit = 5000; I=speye(size(A)); j=0; jmax=100;
while num_err>tol
    j=j+1;
    am_h=am_h*(3/5);
    N=f_h(am_h); 
    if N>1e10
        N=1e10;
    end
    a1_h_gamma=a1_h(am_h);  a2_h_gamma=a2_h(am_h);
    fre_h=@(x) zc-a2_h_gamma*sin(a1_h_gamma)*(exp(x)+exp(-x))*0.5; %real part of the hyperbola
    fim_h=@(x) a2_h_gamma*cos(a1_h_gamma)*(-exp(x)+exp(-x))*0.5;   %imaginary part of the hyperbola
    map_h_g=@(x) fre_h(x)+1i*fim_h(x); %Hyperbolic contour map
    
    U=(map_h_g(0)*I-A)\(u0+b_l(map_h_g(0)));
    res=norm((map_h_g(0)*I-A)*U-u0-b_l(map_h_g(0)));
    ss=svds(map_h_g(0)*I-A,1,'smallestnz',opts)^-1;
    num_err=(c_max_h(am_h)/N)*exp((fre_h(0))*T(end))*ss*res*...
        abs(-a2_h_gamma*sin(a1_h_gamma)*(exp(0)-exp(0))*0.5+...
        1i*(a2_h_gamma*cos(a1_h_gamma)*(exp(0)+exp(0))*0.5));
    
    if j>jmax
        fprintf('Hyperbolic contour, accuracy required may be too high, we suggest to increase tol\n')
        num_err=tol*1e-1;
    end
end
am_h=(5/3)*am_h;
%% Determination of a 
N=20; tol2=tol*1e-1; I=speye(size(A)); x=zeros((N-(floor(N/2+1))),1);
tf=T(end); ti=T(1); flag_TW=0;
while flag_TW==0
    c_max_h=@(a) (1/pi)*log((-X(1)+zc+sqrt((X(1)-zc)^2-(sin(a1_h(a))*(zc-zr)/(sin(a1_h(a)+a)))^2))/(sin(a1_h(a))*(zc-zr)/(sin(a1_h(a)+a))));
    err_n_i=0; err_n_f=0; Mright=1; a_h_old=am_h; err=10;  
    while err>1e-1
        j=j+1;
        if j>jmax
            fprintf('Hyperbolic contour, fail to converge in the search for the optimal N\n')
            break
        end
        f_h=@(a) (c_max_h(a)./(a)).*(log(2*pi*c_max_h(a)*exp(D_h(a)*tf)*Mright+pi*Mleft)-log(tol))+...
                 1e3*(((c_max_h(a)/N)*res*ss*exp((zc-a2_h(a).*sin(a1_h(a)-0)*(exp(0)+exp(0))*0.5)*tf).*...
                 abs(-a2_h(a).*sin(a1_h(a))*(exp(0)-exp(0))*0.5+...
                 1i*(a2_h(a).*cos(a1_h(a))*(-exp(0)-exp(0))*0.5)))>tol);
    
        aa=linspace(0,am_h,100);
        ff_h=f_h(aa); [~,ind]=min(ff_h);
        a_h=(aa(ind));
        a1_h_gamma=a1_h(a_h);  a2_h_gamma=a2_h(a_h);
        fre_h=@(a,x) zc-a2_h_gamma*sin(a1_h_gamma-a)*(exp(x)+exp(-x))*0.5; %real part of the hyperbola
        fim_h=@(a,x) a2_h_gamma*cos(a1_h_gamma-a)*(-exp(x)+exp(-x))*0.5;   %imaginary part of the hyperbola
        map_o_h=@(a,x) fre_h(a,x)+1i*fim_h(a,x); %Hyperbolic Map
        Mright=(1/(2*pi))*norm((map_o_h(a_h,0)*I-A)\(u0+b_l(map_o_h(a_h,0)))*...
            abs(-a2_h_gamma*sin(a1_h_gamma-a_h)*(exp(0)-exp(-0))*0.5+...
                1i*a2_h_gamma*cos(a1_h_gamma-a_h)*(-exp(0)-exp(-0))*0.5));
        err=abs(a_h-a_h_old)/(a_h);
        a_h_old=a_h;
    end
    c_max_h= c_max_h(a_h);
    % Ceck if the amplitude of the TW is accetable
    fre_h=@(x) zc-a2_h_gamma*sin(a1_h_gamma)*(exp(x)+exp(-x))*0.5; %real part of the hyperbola
    fim_h=@(x) a2_h_gamma*cos(a1_h_gamma)*(-exp(x)+exp(-x))*0.5;   %imaginary part of the hyperbola
    map_h_g=@(x) fre_h(x)+1i*fim_h(x); %Hyperbolic contour map
    for i=(floor(N/2+1)):(N-1)
        x(i)=-c_max_h*pi+i*((2*c_max_h*pi)/N);
        U=(map_h_g(x(i))*I-A)\(u0+b_l(map_h_g(x(i))));
        res=norm((map_h_g(x(i))*I-A)*U-u0-b_l(map_h_g(x(i))));
        ss=svds(map_h_g(x(i))*I-A,1,'smallestnz')^-1;
%         err_n_i=err_n_i+2*(c_max_e/N)*exp(((a2_e_gamma+a1_e_gamma)*cos(x(i))+zl)*T(1))*(condi)*((rho_2)^(-1))*eps*max(max(abs(map_e_g(x(i))*I-A)))*norm(U)*...
%             abs(-(a2_e_gamma+a1_e_gamma)*sin(x(i))+1i*(-a2_e_gamma+a1_e_gamma)*cos(x(i)));
%         err_n_f=err_n_f+2*(c_max_e/N)*exp(((a2_e_gamma+a1_e_gamma)*cos(x(i))+zl)*T(end))*(condi)*((rho_2)^(-1))*eps*max(max(abs(map_e_g(x(i))*I-A)))*norm(U)*...
%             abs(-(a2_e_gamma+a1_e_gamma)*sin(x(i))+1i*(-a2_e_gamma+a1_e_gamma)*cos(x(i)));
        err_n_i=err_n_i+2*(c_max_h/N)*exp((fre_h(x(i)))*T(1))*ss*res*...
            abs(-a2_h_gamma*sin(a1_h_gamma)*(exp(x(i))-exp(-x(i)))*0.5+...
                    1i*(a2_h_gamma*cos(a1_h_gamma)*(exp(x(i))+exp(-x(i)))*0.5));
        err_n_f=err_n_f+2*(c_max_h/N)*exp((fre_h(x(i)))*T(end))*ss*res*...
            abs(-a2_h_gamma*sin(a1_h_gamma)*(exp(x(i))-exp(-x(i)))*0.5+...
                    1i*(a2_h_gamma*cos(a1_h_gamma)*(exp(x(i))+exp(-x(i)))*0.5));

    end
    if (err_n_i>tol2)
        ti=(T(1)+T(end))*0.5; T(1)=ti;
        fprintf('Amplitude of the time window is possibly too high to have error of the order of tol in the hyperbolic contour, we proceeded increasing the initial time so that the amplitude is halved\n')
    end
    if (err_n_f>tol2)
         tf=(T(1)+T(end))*0.5; T(end)=tf;
         fprintf('Amplitude of the time window is possibly too high to have error of the order of tol in the hyperbolic contour, we proceeded decreasing the final time so that the amplitude is halved\n')
    end
    if   (err_n_i>tol2)&&(err_n_f>tol2)&&(err_n_i/err_n_f<10)&&(err_n_i/err_n_f>0.1)
        tf=tf+(tf-T(1)); T(end)=tf;
        ti=ti-(tf-T(1)); T(1)=ti;
        fprintf('The problem is possibly ill conditioned, we suggest to lower the tolerance')
        break
    end
    if (err_n_i<tol2)&&((err_n_f<tol2))
        break
    end
end
%% Determination of the truncation value c for the hyperbolc map
%Inizializations
prec=1e-2; K0=80; j=0; jmax=20;
K=K0-2*prec; I=speye(size(A)); c_h=zeros(size(T)); KK=c_h;
fre_h=@(x) zc-a2_h_gamma*sin(a1_h_gamma)*(exp(x)+exp(-x))*0.5; %real part of the hyperbole
fim_h=@(x) a2_h_gamma*cos(a1_h_gamma)*(-exp(x)+exp(-x))*0.5;   %imaginary part of the hyperbole

map_h=@(x) fre_h(x)+1i*fim_h(x); %Hyperbole contour map
for i=1:numel(T)
    while abs(K-K0)>=prec
        
        c_h(i)=(1/pi)*log((zc-(1/T(i))*log(tol/K)+...
            sqrt((zc-(1/T(i))*log(tol/K))^2-(a2_h_gamma^2)*sin(a1_h_gamma)^2))/(a2_h_gamma*sin(a1_h_gamma)));
        u=(map_h(c_h(i)*pi)*I-A)\(u0+b_l(map_h(c_h(i)*pi)));
        K0=K;
        K=(1/(2*pi))*norm(u*(-a2_h_gamma*sin(a1_h_gamma)*(exp(c_h(i)*pi)-exp(-c_h(i)*pi))*0.5+...
            1i*(a2_h_gamma*cos(a1_h_gamma)*(exp(c_h(i)*pi)+exp(-c_h(i)*pi))*0.5)));
        j=j+1;
        if j>jmax
            fprintf('Algorithm for trunctaion did not converge, maximum truncation value automatically selected\n')
            c_h(i)=c_max_h;
            K=(1/(2*pi))*norm(u*(-a2_h_gamma*sin(a1_h_gamma)*(exp(c_h(i)*pi)-exp(-c_h(i)*pi))*0.5+...
            1i*(a2_h_gamma*cos(a1_h_gamma)*(exp(c_h(i)*pi)+exp(-c_h(i)*pi))*0.5)));
            break
        end
      
    end
    if imag(c_h(i))>eps
        fprintf('Algorithm for trunctaion converged to a complex number, maximum truncation value automatically selected\n')
        c_h(i)=c_max_h;
    end
    KK(i)=K;
    K0=80;
end
f_h=@(a) (c_h(1)/(a))*(log(2*pi*c_h(1)*exp(D_h(a)*tf)*Mright+pi*Mleft)-log(tol));
N_h=f_h(a_h);
end