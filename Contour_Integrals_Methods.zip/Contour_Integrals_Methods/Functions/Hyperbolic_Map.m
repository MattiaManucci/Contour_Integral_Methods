%% Function to determine the pseudospectral critical curve
function [a_h,c_h,y_h,map_o_h,a1_h_gamma,a2_h_gamma,c_max_h,N_h] = Hyperbolic_Map(A,b_l,u0,Ar,eps1,eps2,t,nX,zl,zr,zc,tol)
%% Input:
% -A, the matrix of the problem;
% -b_l, the Laplace transfrom of the rhs;
% -u0, initial solution;
% -Ar, coarse discretization of the operator A considered;
% -eps1, target value for the weighted Pseudospectra level curve;
% -eps2, target value for the Pseudospectra level curve;
% -t, time where we would like to compute the solution;
% -nX, maximum number of points where we compute the pseudospctra;
% -zl, see [1];
% -zr, the coordinate of the intersection with the real axes;
% -zc, the center of the hyperbolic profile;
% -tol, target accuracy for the solution;
%% Output:
% -a_h, uniquely defines the map;
% -c_h, determines the truncation of the contour integral;
% -y_h, profile of the critical ellipse;
% -map_o_h, determined map of the contour;
% -a1_h_gamma, see (22) in [1];
% -a2_h_gamma, see (21) in [1];
% -c_max_h, maximum value of the truncation parameter;
% -N_h, see (49) in [1];
%% References
% [1] N. Guglielmi, M. López-Férnandez and M. Manucci, A new pseudospectral roaming contour integral method for solving
% convection diffusion equations, arxiv, 2020.
%% Inizializations
XX=linspace(zl,zr,nX); jj=fix(sqrt(nX)); jj2=2;
r=0.1; d=sum(XX)/numel(XX);
y_h=(zc-zr)*sinh(acosh((zc-XX)/(zc-zr)))/((tan(atan((1/r)*sqrt((d-zc)^2-(zr-zc)^2))))); %Initial Critical Hyperbole
I=speye(size(Ar)); pp=2;
U_1=zeros(size(Ar,1),nX); V_1=zeros(size(Ar,1),nX); S_1=zeros(1,nX); S_2=zeros(1,nX);
flag=1; q=0; j=1; tol_N=1e-2; K=[];
%% Determination of the critical curve
while j<=(nX-1)
    K=[K,j];
    [U,S,V] = svd(full(Ar-(XX(j)+1i*y_h(j))*I),'econ');
    U_1(:,j)=U(:,end); V_1(:,j)=V(:,end); S_1(j)=S(end,end); S_2(j)=S(end,end).*exp(-t*XX(j));
    if ((S(end,end)+(eps2*tol_N))<eps2)||((S(end,end)*exp(-t*XX(j))+(eps1*tol_N))<eps1)
        if j-jj2+1>0
            if S_1(j-jj2+1)<=eps2
                s_2=S_2(j); s_1=S(end,end); u_1=U(:,end); v_1=V(:,end);
                % Note: if k is not a number but a vector the algorithm does
                % not work
                k=K(end);
              
                if (S(end,end)+(eps2*tol_N))>eps2
                    flag=2;
                    if (S(end,end)*exp(-t*XX(j))+(eps1*tol_N))>eps1
                        flag=3;
                        y_h=(zc-zr)*abs((r*sinh(acosh((XX-zc)/(zr-zc))))/(sqrt((d-zc)^2-(zc-zr)^2)));
                    end
                end
                
                for it=1:100
                    
                    if flag==1
                        r0=r;
                        phi=acosh((XX(k)-zc)/(zr-zc));
                        s2=(r0/((eps2)*(max(0,(eps2-s_1)/eps2)/(real(1i*u_1'*v_1)...
                            *(sin(phi)/(((d-zc)^2-(zc-zr)^2)^(1.5)))))));
                        
                        if s2<0.5
                            r=r0+(1/pp)*s2*(eps2)*(max(0,(eps2-s_1)/eps2)/(real(1i*u_1'*v_1)...
                                *(sin(phi)/(((d-zc)^2-(zc-zr)^2)^(1.5)))));
                        else
                            r=r0+(eps2)*(max(0,(eps2-s_1)/eps2)/(real(1i*u_1'*v_1)...
                                *(sin(phi)/(((d-zc)^2-(zc-zr)^2)^(1.5)))));
                        end
                        
                        y_h=(zc-zr)*abs((r*sinh(acosh((XX-zc)/(zr-zc))))/(sqrt((d-zc)^2-(zc-zr)^2)));
                        [U,S,V] = svd(full(Ar-(XX(k)+1i*y_h(k))*I),'econ');
                        u_1=U(:,end); v_1=V(:,end); s_1=S(end,end);
                        s_2=S(end,end).*exp(-t*XX(k));
                       
                        
                        
                        
                        if (S(end,end)+(eps2*tol_N))>eps2
                            if (S(end,end)*exp(-t*XX(j))+(eps1*tol_N))>eps1
                                break
                            else
                                
                                flag=2;
                            end
                        end
                    end
                    
                    if flag==2
                        
                        rr2=r;
                        
                        phi=acosh((XX(k)-zc)/(zr-zc));
                        
                        s2=(rr2(:)/((eps1)*((eps1-s_2)/eps1)/(real(1i*u_1'*v_1)...
                            *(sin(phi)/(((d-zc)^2-(zc-zr)^2)^(1.5))))));
                        if s2<0.5
                            rr2=rr2+(1/pp)*s2*(eps1)*(max(0,(eps1-s_2)/eps1)/(real(1i*u_1'*v_1)...
                                *(sin(phi)/(((d-zc)^2-(zc-zr)^2)^(1.5)))));
                        else
                            rr2=rr2+s2*(eps1)*(((eps1-s_2)/eps1)/(real(1i*u_1'*v_1)...
                                *(sin(phi)/(((d-zc)^2-(zc-zr)^2)^(1.5)))));
                        end
                        
                        y_h=(zc-zr)*abs((rr2*sinh(acosh((XX-zc)/(zr-zc))))/(sqrt((d-zc)^2-(zc-zr)^2)));
                        [U,S,V] = svd(full(Ar-(XX(k)+1i*y_h(k))*I),'econ');
                        u_1=U(:,end); v_1=V(:,end); s_1=S(end,end);
                        s_2=S(end,end).*exp(-t*XX(k));
                        r=rr2;
                        if (S(end,end)+(eps2*tol_N))>eps2
                            if (S(end,end)*exp(-t*XX(j))+(eps1*tol_N))>eps1
                                break
                            else
                                flag=1;
                            end
                        end
                    end
                end
                j=j-jj2+1;
                q=q+1;
            else
                j=j+1+q;
                q=0;
            end
        else
            j=j+1+q;
            q=0;
        end
    else
        j=j+jj;
    end
end
%% Second part of the function where we determine a and c
%% Definition of the Map
rr=r; X=XX;
a1_h=@(a) atan((1/rr).*sqrt((d-zc)^2-(zc-zr)^2))-a;
a2_h=@(a) (zc-zr)./sin(a1_h(a)+a);

fre_h=@(a,x) zc-a2_h(a)*sin(a1_h(a)-a)*(exp(x)+exp(-x))*0.5; %real part of the hyperbole
fim_h=@(a,x) a2_h(a)*cos(a1_h(a)-a)*(-exp(x)+exp(-x))*0.5;   %imaginary part of the hyperbole
map_o_h=@(a,x) fre_h(a,x)+1i*fim_h(a,x); %Hyperbole Map

%% Determination of a
am_h=1e0; amin_h=0;
D_h=@(a) zc-a2_h(a).*sin(a1_h(a)-a); lambda=1e9;
cor_h=@(a) lambda*((zc-a2_h(a)*sin(a1_h(a))-zr)<=0)+((zc-a2_h(a).*sin(a1_h(a))))*((zc-a2_h(a)*sin(a1_h(a))-zr)>0);
c_ott_h=@(a) (1/pi)*log((-X(1)+zc+sqrt((X(1)-zc)^2-(sin(a1_h(a))*(zc-zr)/(sin(a1_h(a)+a)))^2))/(sin(a1_h(a))*(zc-zr)/(sin(a1_h(a)+a))));
f_h=@(a) (c_ott_h(a)./(a)).*(D_h(a)*t-log(tol/(2*c_ott_h(a)*pi)))+0*cor_h(a);
a_h=fminbnd(f_h,amin_h,am_h); c_max_h=c_ott_h(a_h);
a1_h_gamma=a1_h(a_h);  a2_h_gamma=a2_h(a_h);
%% Determination of the truncation value c for the iperbole
%Inizializations
prec=1e-2; K0=80; j=0; 
K=K0-2*prec; I=speye(size(A));
fre_h=@(x) zc-a2_h_gamma*sin(a1_h_gamma)*(exp(x)+exp(-x))*0.5; %real part of the iperbole
fim_h=@(x) a2_h_gamma*cos(a1_h_gamma)*(-exp(x)+exp(-x))*0.5;   %imaginary part of the iperbole

map_h=@(x) fre_h(x)+1i*fim_h(x); %Hyperbole contour map

while abs(K-K0)>=prec
    
    c_h=(1/pi)*log((zc-(1/t)*log(tol/K)+...
        sqrt((zc-(1/t)*log(tol/K))^2-(a2_h_gamma^2)*sin(a1_h_gamma)^2))/(a2_h_gamma*sin(a1_h_gamma)));
    u=(map_h(c_h*pi)*I-A)\(u0+b_l(map_h(c_h*pi)));
    K0=K;
    K=(1/(2*pi))*norm(u*(-a2_h_gamma*sin(a1_h_gamma)*(exp(c_h*pi)-exp(-c_h*pi))*0.5+...
        1i*(a2_h_gamma*cos(a1_h_gamma)*(exp(c_h*pi)+exp(-c_h*pi))*0.5)));
    j=j+1;
   
end
if real(c_h)<=eps
    fprintf('Algorithm for trunctaion converged to imaginary number, maximum truncation value automatically selected')
    c_h=c_ott_h;
end
f_h=@(a) (c_h./(a)).*(D_h(a)*t-log(tol/(2*c_h*pi))); N_h=f_h(a_h);
end



