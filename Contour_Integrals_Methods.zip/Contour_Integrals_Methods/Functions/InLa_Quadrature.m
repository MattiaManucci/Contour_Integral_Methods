function [ Int ] = InLa_Quadrature(A,b_l,u0,t,c,zl,N,a1_gamma,a2_gamma,flag)
%% Input: 
% -A, the matrix of the problem
% -b_l, the Laplace transfrom of the rhs
% -u0, initial solution
% -t, time where I want to compute the solution
% -c, value of the truncation of the Integral 
% -zl/zc, the center of the ellipse/hyperbola,
% -N, vector that contains different numbers of quadrature points.
% -a1_gamma,a2_gamma, parameter to define the map, see [1]. Their
% definition changes according to the profile used.
% flag, if 1 it uses the ellipse contour, if 2 the parabolic, if 3 the
% hyperbolic
%% Output:
% -Int, matrix containg the values of the solution for each quadrature used
%% References
% [1] N. Guglielmi, M. López-Férnandez and M. Manucci, A new pseudospectral roaming contour integral method for solving
% convection diffusion equations, arxiv, 2020.
%% Computations
if flag==1
    fre_e_g=@(x) (a1_gamma*exp(0)+a2_gamma*exp(0))*cos(x)+zl; %real part of the ellipse
    fim_e_g=@(x) (a2_gamma*exp(0)-a1_gamma*exp(0))*sin(x);    %imaginary part of the ellipse
    map_g=@(x) fre_e_g(x)+1i*fim_e_g(x);
end

if flag==2
    fre_p_g=@(x) a2_gamma-x.^2;  %real part of the parabola
    fim_p_g=@(x) -2*x*a1_gamma; %imaginary part of the parabola
    map_g=@(x) fre_p_g(x)+1i*fim_p_g(x);
end

if flag==3
    fre_h_g=@(x) zl-a2_gamma*sin(a1_gamma)*(exp(x)+exp(-x))*0.5; %real part of the hyerbola
    fim_h_g=@(x) -a2_gamma*cos(a1_gamma)*(-exp(x)+exp(-x))*0.5;   %imaginary part of the hyerbola
    map_g=@(x) fre_h_g(x)+1i*fim_h_g(x); %Hyerbolic contour map
end

it=numel(N); Int=zeros(numel(u0),it); I=speye(size(A));

for k=1:numel(N)
    
    x=zeros(1,N(k)-1);
    
    for i=(floor(N(k)/2+1)):(N(k)-1)
        
        x(i)=-c*pi+i*((2*c*pi)/N(k));
        u=(map_g(x(i))*I-A)\(u0+b_l(map_g(x(i))));
     
     
        if flag==1
            Int(:,k)=Int(:,k)+(exp(map_g(x(i))*t)*u*...
                   (-(a1_gamma*exp(0)+a2_gamma*exp(0))*sin(x(i))+...
                      1i*(a2_gamma*exp(0)-a1_gamma*exp(0))*cos(x(i))));
        end
    
        if flag==2
            Int(:,k)=Int(:,k)+(exp(map_g(x(i))*t)*u*(-2*x(i)+1i*(-2)*(a1_gamma)));
        end

        if flag==3
            Int(:,k)=Int(:,k)+(exp(map_g(x(i))*t)*u*(...
                         -a2_gamma*sin(a1_gamma)*(exp(x(i))-exp(-x(i)))*0.5+...
                         1i*(a2_gamma*cos(a1_gamma)*(exp(x(i))+exp(-x(i)))*0.5)));
        end
        
    end
    Int(:,k)=((2*c)/N(k))*imag(Int(:,k));
end

end

