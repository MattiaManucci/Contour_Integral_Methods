clc
clearvars
close all
%% Plot settings and Paths inclusions
FS = 15;       % Fontsize
FN = 'times';  % Fontname
LW = 1.6;      % Linewidth
MS = 7.8;      % Markersize
addpath(genpath('./export_fig/'))
addpath(genpath('./Functions/'))
addpath(genpath('./expm/'))
%% Inizialization of the operator
operator = input('please digit 0 to run Black-Scholes test problem,\nplease digit 1 for Heston test problem,\nplease digit 2 for classical Con-Dif test problem\n');
% Time Window definition
lambda=10;
t1=1; t=[t1, lambda*t1]; zl=(1/t(1))*log(eps); zr=0.06;
%Size of discretization
if operator==0
    dim=2000; %for BS
end
if operator==1
    dim(1)=50; dim(2)=40; %for H
end
if operator==2
    dim(1)=64; %for Classical Con-Dif
end 
[A,b_l,u0,dom] = OPERATORs(dim,t(1),operator);
%% Tolerance and final time
tol=5e-8; flag=1; nt=5;
%% Inizializations of parameters and operators for the weighted pseudospectrum computiation
eps1=1e-7; nX=100; 
%Maximum Trunctation Values
zc=50; bb=(zc-zl)/(zc-zr);
% For the computation of the critical curve we may use an operator of smaller
% size to reduce the complexity
if operator==0
    dim_r=2000; %for BS
end
if operator==1
    dim_r(1)=25; dim_r(2)=20; %for H
end
if operator==2
    dim_r=64; %for Classical Con-Dif
end
[Ar,br_l,u0r] = OPERATORs(dim_r,t(1),operator);
%% Determination of the Integration Profiles
t_e=t;
tic
[a_e,c_e,K_e,y_el,map_o_e,a1_e_gamma,a2_e_gamma,c_max_e,ti_e,tf_e,N_e] = Elliptic_Map_TW(A,b_l,u0,Ar,eps1,t,nX,zl,zr,tol);
t_e(1)=ti_e; t_e(end)=tf_e; TW_e=linspace(t_e(1),t_e(2),nt);
t_p=t;
[a_p,c_p,K_p,y_par,map_o_p,a1_p_gamma,a2_p_gamma,c_max_p,ti_p,tf_p,N_p] = Parabolic_Map_TW(A,b_l,u0,Ar,eps1,t,nX,zl,zr,tol);
t_p(1)=ti_p; t_p(end)=tf_p; TW_p=linspace(t_p(1),t_p(2),nt);
t_h=t;
[a_h,c_h,K_h,y_h,map_o_h,a1_h_gamma,a2_h_gamma,c_max_h,ti_h,tf_h,N_h] = Hyperbolic_Map_TW(A,b_l,u0,Ar,eps1,t,nX,zl,zr,zc,tol);
t_h(1)=ti_h; t_h(end)=tf_h; TW_h=linspace(t_h(1),t_h(2),nt);
%% Determination of solution via quadrature
N=5:2:160;
[Int_e] = InLa_Quadrature_TW(A,b_l,u0,TW_e,c_e,zl,N,a1_e_gamma,a2_e_gamma,1);
[Int_p] = InLa_Quadrature_TW(A,b_l,u0,TW_p,c_p,zl,N,a1_p_gamma,a2_p_gamma,2);
[Int_h] = InLa_Quadrature_TW(A,b_l,u0,TW_h,c_h,zc,N,a1_h_gamma,a2_h_gamma,3);
toc
%% Computation "exact" solution via matrix expon0ential
u_ex_e=Compute_Reference_Solution_TW(dim,operator,A,u0,b_l,TW_e);
u_ex_p=Compute_Reference_Solution_TW(dim,operator,A,u0,b_l,TW_p);
u_ex_h=Compute_Reference_Solution_TW(dim,operator,A,u0,b_l,TW_h);
%% Computation of the errors
err_e=zeros(1,size(Int_e,2)); err_p=zeros(1,size(Int_p,2)); err_h=zeros(1,size(Int_h,2));
for i=1:nt
    for k=1:size(Int_e,2)
        err_e(k,i)=norm(u_ex_e(:,i)-Int_e(:,k,i));
        err_p(k,i)=norm(u_ex_p(:,i)-Int_p(:,k,i));
        err_h(k,i)=norm(u_ex_h(:,i)-Int_h(:,k,i));
    end
end
%% Post-Processing
if mod(floor(N_e)+1,2)==0
    N_e=(floor(N_e)+1)/2;
else
    N_e=(floor(N_e)+2)/2;
end
if mod(floor(N_p)+1,2)==0
    N_p=(floor(N_p)+1)/2;
else
    N_p=(floor(N_p)+2)/2;
end
if mod(floor(N_h)+1,2)==0
    N_h=(floor(N_h)+1)/2;
else
    N_h=(floor(N_h)+2)/2;
end
%% Ellipse
%Error
figure
semilogy(floor((N-1)/2),err_e(:,1),'-r','LineWidth',1.6)
hold on
semilogy(floor((N-1)/2),err_e(:,2),'--b','LineWidth',1.6)
semilogy(floor((N-1)/2),err_e(:,3),'-*g','LineWidth',1.6)
semilogy(floor((N-1)/2),err_e(:,4),'-ok','LineWidth',1.6)
semilogy(floor((N-1)/2),err_e(:,5),'-+c','LineWidth',1.6)
semilogy(floor((N-1)/2),ones(size(N))*tol,':','LineWidth',0.8)
xline(N_e,'LineWidth',0.8)

str=['Elliptic contour, time interval $[$',num2str(t_e(1)),'$,$',num2str(t_e(2)),'$]$'];
title({str},'Interpreter','Latex')
xlabel('N','Interpreter','Latex')
xlim([floor((N(1)-1)/2),floor((N(end)-1)/2)])
ylabel('Absolute Error')
str1=['$t=$',num2str(TW_e(1))]; str2=['$t=$',num2str(TW_e(2))]; str3=['$t=$',num2str(TW_e(3))];
str4=['$t=$',num2str(TW_e(4))]; str5=['$t=$',num2str(TW_e(5))];
lgd=legend(str1,str2,str3,str4,str5,'$tol$','$N_e$','Location','best');
set(lgd,'Interpreter','Latex');

set(gca,'Fontname',FN,'Fontsize',FS);
set(gcf, 'Color', 'w');

%% Parabola
%Error
figure
semilogy(floor((N-1)/2),err_p(:,1),'-r','LineWidth',1.6)
hold on
semilogy(floor((N-1)/2),err_p(:,2),'--b','LineWidth',1.6)
semilogy(floor((N-1)/2),err_p(:,3),'-*g','LineWidth',1.6)
semilogy(floor((N-1)/2),err_p(:,4),'-ok','LineWidth',1.6)
semilogy(floor((N-1)/2),err_p(:,5),'-+c','LineWidth',1.6)
semilogy(floor((N-1)/2),ones(size(N))*tol,':','LineWidth',0.8)
xline(N_p,'LineWidth',0.8)

str=['Parabolic contour, time interval $[$',num2str(t_p(1)),'$,$',num2str(t_p(2)),'$]$'];
title({str},'Interpreter','Latex')
xlabel('N','Interpreter','Latex')
xlim([floor((N(1)-1)/2),floor((N(end)-1)/2)])
ylabel('Absolute Error')
str1=['$t=$',num2str(TW_p(1))]; str2=['$t=$',num2str(TW_p(2))]; str3=['$t=$',num2str(TW_p(3))];
str4=['$t=$',num2str(TW_p(4))]; str5=['$t=$',num2str(TW_p(5))];
lgd=legend(str1,str2,str3,str4,str5,'$tol$','$N_p$','Location','best');
set(lgd,'Interpreter','Latex');

set(gca,'Fontname',FN,'Fontsize',FS);
set(gcf, 'Color', 'w');

%% Hyperbola
%Error
figure
semilogy(floor((N-1)/2),err_h(:,1),'-r','LineWidth',1.6)
hold on
semilogy(floor((N-1)/2),err_h(:,2),'--b','LineWidth',1.6)
semilogy(floor((N-1)/2),err_h(:,3),'-*g','LineWidth',1.6)
semilogy(floor((N-1)/2),err_h(:,4),'-ok','LineWidth',1.6)
semilogy(floor((N-1)/2),err_h(:,5),'-+c','LineWidth',1.6)
semilogy(floor((N-1)/2),ones(size(N))*tol,':','LineWidth',0.8)
xline(N_h,'LineWidth',0.8)

str=['Hyperbolic contour, time interval $[$',num2str(t_h(1)),'$,$',num2str(t_h(2)),'$]$'];
title({str},'Interpreter','Latex')
xlabel('N','Interpreter','Latex')
xlim([floor((N(1)-1)/2),floor((N(end)-1)/2)])
ylabel('Absolute Error')
str1=['$t=$',num2str(TW_h(1))]; str2=['$t=$',num2str(TW_h(2))]; str3=['$t=$',num2str(TW_h(3))];
str4=['$t=$',num2str(TW_h(4))]; str5=['$t=$',num2str(TW_h(5))];
lgd=legend(str1,str2,str3,str4,str5,'$tol$','$N_h$','Location','best');
set(lgd,'Interpreter','Latex');

set(gca,'Fontname',FN,'Fontsize',FS);
set(gcf, 'Color', 'w');

%% Contour Iintegration Profiles
fre_e=@(x) (a1_e_gamma*exp(0)+a2_e_gamma*exp(0))*cos(x)+zl; %real part of the ellipse
fim_e=@(x) (a2_e_gamma*exp(0)-a1_e_gamma*exp(0))*sin(x);    %imaginary part  
map_e=@(x) fre_e(x)+1i*fim_e(x);

fre_p=@(x) a2_p_gamma-x.^2;  %real part of the parabola
fim_p=@(x) -2*x*a1_p_gamma; %imaginary part of the parabola
map_p=@(x) fre_p(x)+1i*fim_p(x);

fre_h=@(x) zc-a2_h_gamma*sin(a1_h_gamma)*(exp(x)+exp(-x))*0.5; %real part of the hyperbola
fim_h=@(x) -a2_h_gamma*cos(a1_h_gamma)*(-exp(x)+exp(-x))*0.5;   %imaginary part of the hyperbola
map_h=@(x) fre_h(x)+1i*fim_h(x); %Hyperbola contour map

i=1:1:39; Nq=40; m=1;
x_e=-c_e(1)*pi+i.*((2*c_e(1)*pi)/Nq);
x_p=-m*c_p(1)*pi+i.*((2*m*c_p(1)*pi)/Nq);
x_h=-m*c_h(1)*pi+i.*((2*m*c_h(1)*pi)/Nq);
figure
plot(map_e(x_e),'--ob')
hold on
plot(map_p(x_p),'-+r')
plot(map_h(x_h),'-*k')
grid on

str=['$N_q=$',num2str(Nq)];
title('Contour Curves with Quadrature P.','Interpreter','Latex')
xlabel('Re(z)','Interpreter','Latex')
ylabel('iIm(z)')
lgd=legend('Ellipse','Parabola','Hyperbole','Location','best');
set(lgd,'Interpreter','Latex');

set(gca,'Fontname',FN,'Fontsize',FS);
set(gcf, 'Color', 'w');