clc
clearvars
close all
%% Plot settings and Paths inclusions
FS = 15;       % Fontsize
FN = 'times';  % Fontname
LW = 1.6;      % Linewidth
MS = 7.8;      % Markersize
addpath(genpath('./export_fig/'))
addpath(genpath('./Functions/'))
Heston='Input/Heston';
%% Inizialization of the operator
operator = input('please digit 0 to run Black-Scholes test problem,\nplease digit 1 for Heston test problem,\nplease digit 2 for classical Con-Dif test problem\n');
%Size of the discretization
t=1; tol_1=eps; zl=(1/t)*log(eps); zr=0.06;
if operator==0
    dim=200; %for BS
end
if operator==1
    dim(1)=50; dim(2)=40; %for H
end
if operator==2
    dim(1)=64; %for Classical Con-Dif
end
[A,b_l,u0,dom] = OPERATORs(dim,t,operator);
%% Tolerance and final time
tol=5e-9; flag=1;
%% Determination of the Pseudo-Spectra Critical Curve of the Matrix A
eps1=1e-9; eps2=1e-13; nX=100; 
%Maximum Trunctation Values
zc=50; bb=(zc-zl)/(zc-zr);
% For the computation of the critical curve we use an operator of smaller
% size to reduce the complexity
if operator==0
    dim_r=200; %for BS
end
if operator==1
    dim_r(1)=25; dim_r(2)=20; %for H
end
if operator==2
    dim_r=64; %for Classical Con-Dif
end
[Ar,br_l,u0r] = OPERATORs(dim_r,t,operator);
%% Determination of the Integration Profiles
[a_e,c_e,y_el,map_o_e,a1_e_gamma,a2_e_gamma,c_max_e,N_e] = Elliptic_Map(A,b_l,u0,Ar,eps1,eps2,t,nX,zl,zr,tol);
[a_p,c_p,y_par,map_o_p,a1_p_gamma,a2_p_gamma,c_max_p,N_p]= Parabolic_Map(A,b_l,u0,Ar,eps1,eps2,t,nX,zl,zr,tol);
[a_h,c_h,y_h,map_o_h,a1_h_gamma,a2_h_gamma,c_max_h,N_h] = Hyperbolic_Map(A,b_l,u0,Ar,eps1,eps2,t,nX,zl,zr,zc,tol);
%% Determination of solution via quadrature
N=5:2:70;
[Int_e] = InLa_Quadrature(A,b_l,u0,t,c_e,zl,N,a1_e_gamma,a2_e_gamma,1);
[Int_p] = InLa_Quadrature(A,b_l,u0,t,c_p,zl,N,a1_p_gamma,a2_p_gamma,2);
[Int_h] = InLa_Quadrature(A,b_l,u0,t,c_h,zc,N,a1_h_gamma,a2_h_gamma,3);
%% Computation of the error
err_e=Compute_Errors(dim,operator,Int_e,A,u0,b_l,t);
err_p=Compute_Errors(dim,operator,Int_p,A,u0,b_l,t);
err_h=Compute_Errors(dim,operator,Int_h,A,u0,b_l,t);
%% Post-Processing
%Error
figure
semilogy(floor((N-1)/2),err_e,'b','LineWidth',1.6)
hold on
semilogy(floor((N-1)/2),err_p,'--r','LineWidth',1.6)
semilogy(floor((N-1)/2),err_h,':ok','LineWidth',1.6)
grid on
% str=['$tol=$',num2str(tol),' $eps_1=$',num2str(eps1),' $eps_2=$',num2str(eps2)];
str=['$tol=$',num2str(tol)];
title({str},'Interpreter','Latex')
xlabel('N','Interpreter','Latex')
xlim([floor((N(1)-1)/2),floor((N(end)-1)/2)])
ylabel('Absolute Error')
lgd=legend('Ellipse','Parabola','Hyperbole','Location','best');
set(lgd,'Interpreter','Latex');

set(gca,'Fontname',FN,'Fontsize',FS);
set(gcf, 'Color', 'w');
%% Crtical Curve
figure
X=linspace(zl,zr,nX);
plot(X,y_el,':b','LineWidth',1.6)
hold on
plot(X,y_par,'--r','LineWidth',1)
plot(X,y_h,'-k','LineWidth',1)

title('Critical Curves','Interpreter','Latex')
xlabel('Re(z)');
ylabel('iIm(z)');
lgd=legend('Critical Ellipse','Critical Parabola','Critical Hyperbole','Location','best');
set(lgd,'Interpreter','Latex');

set(gca,'Fontname',FN,'Fontsize',FS);
set(gcf, 'Color', 'w');
%export_fig  Critical_Curves_Heston.pdf -native

%% Contour Integral
fre_e=@(x) (a1_e_gamma*exp(0)+a2_e_gamma*exp(0))*cos(x)+zl; %real part of the ellisse
fim_e=@(x) (a2_e_gamma*exp(0)-a1_e_gamma*exp(0))*sin(x);    %imaginary part of the ellisse
map_e=@(x) fre_e(x)+1i*fim_e(x);

fre_p=@(x) a2_p_gamma-x.^2;  %real part of the parabola
fim_p=@(x) -2*x*a1_p_gamma; %imaginary part of the parabola
map_p=@(x) fre_p(x)+1i*fim_p(x);

fre_h=@(x) zc-a2_h_gamma*sin(a1_h_gamma)*(exp(x)+exp(-x))*0.5; %real part of the iperbole
fim_h=@(x) -a2_h_gamma*cos(a1_h_gamma)*(-exp(x)+exp(-x))*0.5;   %imaginary part of the iperbole
map_h=@(x) fre_h(x)+1i*fim_h(x); %Hyperbole contour map

i=1:1:39; Nq=40;
x_e=-c_e*pi+i.*((2*c_e*pi)/Nq);
x_p=-c_p*pi+i.*((2*c_p*pi)/Nq);
x_h=-c_h*pi+i.*((2*c_h*pi)/Nq);
figure
plot(map_e(x_e),'--ob')
hold on
plot(map_p(x_p),'-+r')
plot(map_h(x_h),'-*k')
grid on

str=['$N_q=$',num2str(Nq)];
title('Contour Curves with Quadrature P.','Interpreter','Latex')
xlabel('Re(z)','Interpreter','Latex')
ylabel('iIm(z)')
lgd=legend('Ellipse','Parabola','Hyperbole','Location','best');
set(lgd,'Interpreter','Latex');

set(gca,'Fontname',FN,'Fontsize',FS);
set(gcf, 'Color', 'w');

