clc
clearvars
close all
%% Plot settings and Paths inclusions
FS = 15;       % Fontsize
FN = 'times';  % Fontname
LW = 1.6;      % Linewidth
MS = 7.8;      % Markersize
addpath(genpath('./export_fig/'))
addpath(genpath('./Functions/'))
addpath(genpath('./expm/'))
%% Inizialization of the operator
operator = input('please digit 0 to run Black-Scholes test problem,\nplease digit 1 for Heston test problem,\nplease digit 2 for classical Con-Dif test problem\n');
%Size of discretization
t=10; tol_1=eps; zl=(1/t)*log(eps); zr=0.06;
if operator==0
    dim=2000; %for BS
end
if operator==1
    dim(1)=50; dim(2)=40; %for H
end
if operator==2
    dim(1)=64; %for Classical Con-Dif
end
% Contructing the operator
[A,b_l,u0,dom] = OPERATORs(dim,t,operator);
%% Tolerance and final time
tol=5e-7; flag=1;
%% Inizializations of parameters and operators for the weighted pseudospectrum computiation
eps1=1e-7; nX=100; zc=50; bb=(zc-zl)/(zc-zr);
% For the computation of the critical curve we may use an operator of smaller
% size to reduce the complexity
if operator==0
    dim_r=2000; %for BS
end
if operator==1
    dim_r(1)=50; dim_r(2)=40; %for H
end
if operator==2
    dim_r=64; %for Classical Con-Dif
end
[Ar,br_l,u0r] = OPERATORs(dim_r,t,operator);
%% Determination of the Integration Profiles
[a_e,c_e,y_el,map_o_e,a1_e_gamma,a2_e_gamma,c_max_e,N_e] = Elliptic_Map(A,b_l,u0,Ar,eps1,t,nX,zl,zr,tol);
[a_p,c_p,y_par,map_o_p,a1_p_gamma,a2_p_gamma,c_max_p,N_p] = Parabolic_Map(A,b_l,u0,Ar,eps1,t,nX,zl,zr,tol);
[a_h,c_h,y_h,map_o_h,a1_h_gamma,a2_h_gamma,c_max_h,N_h] = Hyperbolic_Map(A,b_l,u0,Ar,eps1,t,nX,zl,zr,zc,tol);
%% Determination of solution via quadrature
N=5:2:130;
[Int_e] = InLa_Quadrature(A,b_l,u0,t,c_e,zl,N,a1_e_gamma,a2_e_gamma,1);
[Int_p] = InLa_Quadrature(A,b_l,u0,t,c_p,zl,N,a1_p_gamma,a2_p_gamma,2);
[Int_h] = InLa_Quadrature(A,b_l,u0,t,c_h,zc,N,a1_h_gamma,a2_h_gamma,3);
%% Computation "exact" solution via matrix exponential
u_ex=Compute_Reference_Solution(dim,operator,A,u0,b_l,t);
%% Computation of the errors
err_e=zeros(1,size(Int_e,2)); err_p=zeros(1,size(Int_p,2)); err_h=zeros(1,size(Int_h,2)); 
for k=1:size(Int_e,2)
    err_e(k)=norm(u_ex-Int_e(:,k));
    err_p(k)=norm(u_ex-Int_p(:,k));
    err_h(k)=norm(u_ex-Int_h(:,k));
end
%% Post-Processing
% Find the N estimate to reach accuracy tol
if mod(floor(N_e)+1,2)==0
    N_e=(floor(N_e)+1)/2;
else
    N_e=(floor(N_e)+2)/2;
end
if mod(floor(N_p)+1,2)==0
    N_p=(floor(N_p)+1)/2;
else
    N_p=(floor(N_p)+2)/2;
end
if mod(floor(N_h)+1,2)==0
    N_h=(floor(N_h)+1)/2;
else
    N_h=(floor(N_h)+2)/2;
end
ind_e=find(floor((N-1)/2)==N_e);
ind_p=find(floor((N-1)/2)==N_p);
ind_h=find(floor((N-1)/2)==N_h);
%Error
figure
semilogy(floor((N-1)/2),err_e,'-.b','LineWidth',1.6)
hold on
semilogy(floor((N-1)/2),err_p,'--r','LineWidth',1.6)
semilogy(floor((N-1)/2),err_h,'k','LineWidth',1.6)
semilogy(floor((N-1)/2),ones(size(N))*tol,':','LineWidth',0.8)
semilogy(N_e,err_e(ind_e),'bo','LineWidth',2)
semilogy(N_p,err_p(ind_p),'ro','LineWidth',2)
semilogy(N_h,err_h(ind_h),'ko','LineWidth',2)
% str=['$tol=$',num2str(tol),' $eps_1=$',num2str(eps1),' $eps_2=$',num2str(eps2)];
str=['$tol=$',num2str(tol)];
title({str},'Interpreter','Latex')
xlabel('N','Interpreter','Latex')
xlim([floor((N(1)-1)/2),floor((N(end)-1)/2)])
%ylim([min(err_h)*1e-1,max(err_h)*10])
ylabel('Absolute Error')
lgd=legend('Ellipse','Parabola','Hyperbole','$tol$','Interpreter','Latex');
set(lgd,'Interpreter','Latex');

set(gca,'Fontname',FN,'Fontsize',FS);
set(gcf, 'Color', 'w');

%% Crtical Curve
figure
X=linspace(zl,zr,nX);
plot(X,y_el,':b','LineWidth',1.6)
hold on
plot(X,y_par,'--r','LineWidth',1)
plot(X,y_h,'-k','LineWidth',1)

title('Critical Curves','Interpreter','Latex')
xlabel('Re(z)');
ylabel('iIm(z)');
lgd=legend('Critical Ellipse','Critical Parabola','Critical Hyperbole','Location','best');
set(lgd,'Interpreter','Latex');

set(gca,'Fontname',FN,'Fontsize',FS);
set(gcf, 'Color', 'w');

%% Contour Integral
fre_e=@(x) (a1_e_gamma*exp(0)+a2_e_gamma*exp(0))*cos(x)+zl; %real part of the ellipse
fim_e=@(x) (a2_e_gamma*exp(0)-a1_e_gamma*exp(0))*sin(x);    %imaginary part of the ellipse
map_e=@(x) fre_e(x)+1i*fim_e(x); %Ellipse contour map

fre_p=@(x) a2_p_gamma-x.^2;  %real part of the parabola
fim_p=@(x) -2*x*a1_p_gamma; %imaginary part of the parabola
map_p=@(x) fre_p(x)+1i*fim_p(x); %Parabola contour map

fre_h=@(x) zc-a2_h_gamma*sin(a1_h_gamma)*(exp(x)+exp(-x))*0.5; %real part of the hyperbola
fim_h=@(x) -a2_h_gamma*cos(a1_h_gamma)*(-exp(x)+exp(-x))*0.5;  %imaginary part of the hyperbola
map_h=@(x) fre_h(x)+1i*fim_h(x); %Hyperbola contour map

i=1:1:39; Nq=40;
x_e=-c_e*pi+i.*((2*c_e*pi)/Nq);
x_p=-c_p*pi+i.*((2*c_p*pi)/Nq);
x_h=-c_h*pi+i.*((2*c_h*pi)/Nq);
figure
plot(map_e(x_e),'--ob')
hold on
plot(map_p(x_p),'-+r')
plot(map_h(x_h),'-*k')
grid on

str=['$N_q=$',num2str(Nq)];
title('Contour Curves with Quadrature P.','Interpreter','Latex')
xlabel('Re(z)','Interpreter','Latex')
ylabel('iIm(z)')
lgd=legend('Ellipse','Parabola','Hyperbole','Location','best');
set(lgd,'Interpreter','Latex');

set(gca,'Fontname',FN,'Fontsize',FS);
set(gcf, 'Color', 'w');

