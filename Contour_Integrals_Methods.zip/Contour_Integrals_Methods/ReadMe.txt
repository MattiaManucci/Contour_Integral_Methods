Main: script to compute the solution at a given time t with countour integral methods developed in [1].
Main_Time_Window: script to compute the solution on a given time window [t0,t1] with countour integral methods developed in [1].
Functions: folder that contains the functions which implement passages of the routine described in [1]. Each function is shortly commented with a description of its: role, input arguments and output arguments.  

Reference:
[1] N. Guglielmi, M. LÃ³pez-FÃ©rnandez and M. Manucci, A new pseudospectral roaming contour integral method for solving convection diffusion equations, arxiv, 2020.