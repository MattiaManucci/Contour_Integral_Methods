Main: script to compute the solution at a given time t with countour integral methods developed in [1].
Main_Time_Window: script to compute the solution on a given time window [t0,t1] with countour integral methods developed in [1].
Functions: folder that contains the functions which implement passages of the routine described in [1]. Each function is shortly commented with a description of: role, input arguments and output arguments.  
expmv: folder that contains the functions to compute the matrix exponential, see [2].  



Reference:
[1] N. Guglielmi, M. LÃ³pez-FÃ©rnandez and M. Manucci, A new pseudospectral roaming contour integral method for solving convection diffusion equations, arxiv, 2020.
[2] A. H. Al-Mohy and N. J. Higham, "Computing the action of the matrix exponential, with an application to exponential integrators" SIAM J. Sci. Comput., 33(2):488--511, 2011.